#!/bin/bash

# WiFi WPS Tester - Build Script
# This script helps build the Android application

set -e  # Exit on any error

echo "🔒 WiFi WPS Tester - Build Script"
echo "=================================="
echo ""

# Check if Android SDK is available
if [ -z "$ANDROID_HOME" ]; then
    echo "❌ Error: ANDROID_HOME environment variable is not set"
    echo "Please install Android SDK and set ANDROID_HOME"
    exit 1
fi

echo "✅ Android SDK found at: $ANDROID_HOME"

# Check for Java
if ! command -v java &> /dev/null; then
    echo "❌ Error: Java is not installed or not in PATH"
    exit 1
fi

echo "✅ Java found: $(java -version 2>&1 | head -n 1)"

# Make gradlew executable
chmod +x ./gradlew

echo ""
echo "🔧 Building the application..."
echo ""

# Clean previous builds
echo "🧹 Cleaning previous builds..."
./gradlew clean

# Build debug APK
echo "🔨 Building debug APK..."
./gradlew assembleDebug

# Check if build was successful
if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
    echo ""
    echo "✅ Build successful!"
    echo "📱 APK location: app/build/outputs/apk/debug/app-debug.apk"
    echo ""
    echo "📋 Next steps:"
    echo "1. Enable 'Install from Unknown Sources' on your Android device"
    echo "2. Transfer the APK to your device"
    echo "3. Install and grant necessary permissions"
    echo "4. Read and accept the legal disclaimer"
    echo ""
    echo "⚠️  REMEMBER: Use only for educational purposes and authorized testing!"
else
    echo ""
    echo "❌ Build failed!"
    echo "Please check the error messages above"
    exit 1
fi

echo "🎓 Happy learning and ethical testing!"