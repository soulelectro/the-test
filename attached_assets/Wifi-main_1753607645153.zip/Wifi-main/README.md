# WiFi WPS Tester – No Root

<div align="center">
  <img src="https://img.shields.io/badge/Android-11%2B-green" alt="Android 11+">
  <img src="https://img.shields.io/badge/Kotlin-1.9.20-blue" alt="Kotlin">
  <img src="https://img.shields.io/badge/Material%20Design-3-purple" alt="Material Design 3">
  <img src="https://img.shields.io/badge/License-Educational-orange" alt="Educational License">
</div>

## 🔒 Educational WiFi Security Testing Tool

A comprehensive Android application for **educational purposes** and **authorized security testing** of WiFi networks with WPS vulnerabilities. This app works completely **offline** and requires **no root access**.

## ⚠️ LEGAL DISCLAIMER

**🚨 FOR EDUCATIONAL AND AUTHORIZED TESTING ONLY 🚨**

- ✅ **PERMITTED**: Testing your own networks, educational learning, authorized penetration testing
- ❌ **PROHIBITED**: Testing unauthorized networks, illegal access, malicious activities
- 📝 **RESPONSIBILITY**: Users are solely responsible for their actions and must comply with all laws
- 🌍 **COMPLIANCE**: Use only on networks you own or have explicit written permission to test

## 🌟 Key Features

### 📶 WiFi Network Scanner
- Real-time WiFi network discovery using Android's WifiManager API
- Beautiful Material Design 3 cards displaying network information
- Signal strength indicators with visual bars
- Security protocol detection (WPA/WPA2/WPA3/WEP/Open)
- WPS-enabled network highlighting
- Manufacturer identification via MAC OUI lookup
- Risk level assessment and color-coded warnings

### 🔐 WPS Vulnerability Testing
- **Default PIN Testing**: Extensive database of manufacturer default PINs
- **Manual PIN Input**: Custom PIN testing capability
- **Dictionary Attack**: Common PIN pattern testing
- **Sequential Testing**: Systematic PIN enumeration
- **Manufacturer-Specific**: Targeted testing based on router brand
- **Lockout Detection**: WPS lockout simulation and handling
- **Adjustable Delays**: Configurable delay between attempts (1-10 seconds)

### 📊 Comprehensive Analytics
- **Risk Assessment**: Automatic vulnerability scoring
- **Test Statistics**: Success rates, duration tracking, attempt counts
- **Historical Data**: Complete test history with timestamps
- **Manufacturer Analysis**: Vulnerability patterns by brand
- **Export Capabilities**: JSON, CSV, and PDF report generation

### 🛡️ Security Intelligence (Offline)
- **CVE Database**: Known vulnerabilities for detected manufacturers
- **Security Recommendations**: Personalized advice for each network
- **Router Fingerprinting**: Model identification and risk assessment
- **Threat Detection**: Spoofed SSID and evil twin detection alerts

### 🎓 Educational Content
- **WPS Fundamentals**: Understanding WPS technology and protocols
- **Attack Methodologies**: How brute-force and Pixie Dust attacks work
- **Security Best Practices**: Router hardening and configuration guides
- **Historical Context**: KRACK, WPA vulnerabilities, and security evolution
- **Ethical Hacking**: Responsible disclosure and testing guidelines

### 📱 Modern UI/UX
- **Material Design 3**: Beautiful, accessible interface
- **Dynamic Theming**: Light/dark mode with system integration
- **Responsive Design**: Optimized for phones and tablets
- **Intuitive Navigation**: Bottom navigation with clear sections
- **Real-time Updates**: Live progress indicators and status updates

## 🔧 Technical Architecture

### **Offline-First Design**
- ✅ **No Internet Required**: All functionality works completely offline
- 🗄️ **Local Database**: Room database for persistent storage
- 📊 **Embedded Data**: Manufacturer OUIs, default PINs, CVE database
- 🔒 **Privacy Focused**: No data transmitted to external servers

### **Modern Android Stack**
- **Language**: Kotlin with coroutines for asynchronous operations
- **Architecture**: MVVM with Repository pattern
- **Dependency Injection**: Hilt for clean architecture
- **Database**: Room with TypeConverters for complex data
- **UI Framework**: Jetpack Compose with Material Design 3
- **Navigation**: Navigation Compose with bottom navigation
- **State Management**: StateFlow and Compose state

### **Security & Permissions**
- **Minimal Permissions**: Only essential WiFi and location permissions
- **No Root Required**: Uses standard Android APIs exclusively
- **Educational Simulation**: Real testing concepts with safe implementation
- **Data Protection**: Local storage with backup/restore support

## 📋 System Requirements

- **Android Version**: 11.0 (API level 30) or higher
- **RAM**: 2GB minimum, 4GB recommended
- **Storage**: 100MB for app and database
- **Hardware**: WiFi capability required
- **Permissions**: Location access for WiFi scanning

## 🚀 Installation

### Option 1: Build from Source
```bash
# Clone the repository
git clone https://github.com/your-repo/wifi-wps-tester.git
cd wifi-wps-tester

# Build with Gradle
./gradlew assembleDebug

# Install on connected device
./gradlew installDebug
```

### Option 2: Download APK
1. Download the latest APK from the [Releases](https://github.com/your-repo/wifi-wps-tester/releases) page
2. Enable "Install from Unknown Sources" in Android settings
3. Install the APK file
4. Grant required permissions when prompted

## 📖 Usage Guide

### 1. First Launch
- Read and accept the legal disclaimer
- Grant location and WiFi permissions
- Complete the brief educational introduction

### 2. Network Scanning
- Tap "Start WiFi Scan" to discover nearby networks
- View networks sorted by signal strength, risk level, or name
- Filter to show only WPS-enabled networks
- Tap any network for detailed information

### 3. Security Analysis
- Review risk assessment and security recommendations
- Check manufacturer-specific vulnerabilities
- View default PIN suggestions for the router brand
- Read educational content about detected security issues

### 4. WPS Testing (Educational)
- Select a network you own or have permission to test
- Choose testing method (default PINs, manual, dictionary)
- Configure delay between attempts
- Monitor real-time progress and results
- Review detailed test logs and statistics

### 5. Results & Export
- Browse complete test history
- Filter results by date, network, or outcome
- Export data in JSON, CSV, or PDF format
- Generate security assessment reports

## 🔍 Supported Router Brands

The app includes extensive offline databases for:

### Major Manufacturers
- **TP-Link**: 50+ OUI prefixes, 25+ default PINs
- **D-Link**: 30+ OUI prefixes, 20+ default PINs  
- **Netgear**: 25+ OUI prefixes, 15+ default PINs
- **Linksys**: 30+ OUI prefixes, 12+ default PINs
- **ASUS**: 20+ OUI prefixes, 10+ default PINs
- **Belkin**: 15+ OUI prefixes, 8+ default PINs

### Enterprise Equipment
- **Cisco**: 100+ OUI prefixes, enterprise vulnerability database
- **Ubiquiti**: 10+ OUI prefixes, UniFi-specific testing
- **MikroTik**: 8+ OUI prefixes, RouterOS vulnerability data

## 🛠️ Development

### Project Structure
```
app/
├── src/main/java/com/wifiwpstester/noroot/
│   ├── data/
│   │   ├── database/          # Room database components
│   │   ├── model/             # Data models and entities
│   │   ├── repository/        # Offline data repository
│   │   └── service/           # WiFi scanning and testing services
│   ├── di/                    # Hilt dependency injection
│   ├── ui/
│   │   ├── navigation/        # Navigation components
│   │   ├── screens/           # Compose UI screens
│   │   ├── theme/             # Material Design 3 theming
│   │   └── viewmodel/         # ViewModels for UI state
│   └── WifiWpsApplication.kt  # Application class
├── src/main/res/
│   ├── values/                # Strings, colors, themes
│   └── xml/                   # Backup and data extraction rules
└── build.gradle.kts           # Build configuration
```

### Key Dependencies
```kotlin
// Core Android
implementation("androidx.core:core-ktx:1.12.0")
implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")

// Compose UI
implementation("androidx.compose.ui:ui")
implementation("androidx.compose.material3:material3")
implementation("androidx.navigation:navigation-compose:2.7.5")

// Architecture
implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
implementation("androidx.room:room-ktx:2.6.1")
implementation("com.google.dagger:hilt-android:2.48")

// Utilities
implementation("com.google.code.gson:gson:2.10.1")
implementation("com.itextpdf:itext7-core:7.2.5")
```

## 🤝 Contributing

We welcome contributions that enhance the educational value and security research capabilities of this tool:

### Contribution Guidelines
1. **Educational Focus**: All contributions must maintain educational intent
2. **Legal Compliance**: No features that enable illegal activities
3. **Code Quality**: Follow Kotlin coding standards and architecture patterns
4. **Documentation**: Include comprehensive documentation for new features
5. **Testing**: Add unit tests for new functionality

### Areas for Contribution
- 🔍 **Vulnerability Database**: Additional CVE entries and manufacturer data
- 📚 **Educational Content**: Security tutorials and best practices
- 🎨 **UI/UX**: Interface improvements and accessibility features
- 🔧 **Testing**: Additional test scenarios and edge cases
- 🌐 **Localization**: Translations for international users

## 📄 License

This project is licensed under the **Educational Use License** - see the [LICENSE](LICENSE) file for details.

### License Summary
- ✅ **Educational Use**: Permitted for learning and research
- ✅ **Non-Commercial**: Free for educational institutions
- ✅ **Attribution**: Credit required for derivative works
- ❌ **Commercial Use**: Requires separate licensing agreement
- ❌ **Malicious Use**: Strictly prohibited

## 🙋‍♂️ Support & Community

### Getting Help
- 📖 **Documentation**: Check the [Wiki](https://github.com/your-repo/wifi-wps-tester/wiki)
- 🐛 **Bug Reports**: Use [GitHub Issues](https://github.com/your-repo/wifi-wps-tester/issues)
- 💬 **Discussions**: Join [GitHub Discussions](https://github.com/your-repo/wifi-wps-tester/discussions)
- 📧 **Security Issues**: security@wifiwpstester.com

### Community Guidelines
- Be respectful and professional
- Focus on educational and ethical use cases
- Share knowledge and help others learn
- Report security vulnerabilities responsibly

## ⚖️ Ethical Use Statement

This application is designed to promote **cybersecurity education** and **responsible security research**. We strongly encourage:

- 🎓 **Learning**: Understanding WiFi security concepts and vulnerabilities
- 🔒 **Protection**: Securing your own networks and helping others do the same
- 📝 **Responsible Disclosure**: Reporting vulnerabilities through proper channels
- 🤝 **Community**: Sharing knowledge and best practices with the security community

**Remember**: With great power comes great responsibility. Use this tool ethically and legally.

---

<div align="center">
  <p><strong>Made with ❤️ for the cybersecurity education community</strong></p>
  <p><em>Promoting ethical hacking and responsible security research</em></p>
</div>