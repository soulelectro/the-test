package com.wifiwpstester.noroot.ui.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import com.wifiwpstester.noroot.ui.screens.*
import com.wifiwpstester.noroot.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiWpsNavigation(
    navController: NavHostController,
    viewModel: MainViewModel
) {
    val currentTab by viewModel.currentTab.collectAsState()
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (currentTab) {
                            0 -> "WiFi Scanner"
                            1 -> "Test Results"
                            2 -> "Educational"
                            3 -> "Settings"
                            else -> "WiFi WPS Tester"
                        }
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        bottomBar = {
            NavigationBar {
                val navigationItems = listOf(
                    NavigationItem(
                        route = "scanner",
                        icon = Icons.Default.Wifi,
                        label = "Scan",
                        index = 0
                    ),
                    NavigationItem(
                        route = "results",
                        icon = Icons.Default.History,
                        label = "Results",
                        index = 1
                    ),
                    NavigationItem(
                        route = "education",
                        icon = Icons.Default.School,
                        label = "Learn",
                        index = 2
                    ),
                    NavigationItem(
                        route = "settings",
                        icon = Icons.Default.Settings,
                        label = "Settings",
                        index = 3
                    )
                )
                
                navigationItems.forEach { item ->
                    NavigationBarItem(
                        icon = { 
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.label
                            )
                        },
                        label = { Text(item.label) },
                        selected = currentTab == item.index,
                        onClick = {
                            viewModel.setCurrentTab(item.index)
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.startDestinationId) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = "scanner",
            modifier = Modifier.padding(paddingValues)
        ) {
            composable("scanner") {
                WifiScannerScreen(viewModel = viewModel)
            }
            
            composable("results") {
                TestResultsScreen(viewModel = viewModel)
            }
            
            composable("education") {
                EducationScreen(viewModel = viewModel)
            }
            
            composable("settings") {
                SettingsScreen(viewModel = viewModel)
            }
            
            composable("network_details/{bssid}") { backStackEntry ->
                val bssid = backStackEntry.arguments?.getString("bssid") ?: ""
                NetworkDetailsScreen(
                    bssid = bssid,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            
            composable("wps_test/{bssid}") { backStackEntry ->
                val bssid = backStackEntry.arguments?.getString("bssid") ?: ""
                WpsTestScreen(
                    bssid = bssid,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}

data class NavigationItem(
    val route: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String,
    val index: Int
)