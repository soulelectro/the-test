package com.wifiwpstester.noroot.di

import android.content.Context
import androidx.room.Room
import com.wifiwpstester.noroot.data.database.WifiNetworkDao
import com.wifiwpstester.noroot.data.database.WifiWpsDatabase
import com.wifiwpstester.noroot.data.database.WpsTestDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    
    @Provides
    @Singleton
    fun provideWifiWpsDatabase(@ApplicationContext context: Context): WifiWpsDatabase {
        return Room.databaseBuilder(
            context.applicationContext,
            WifiWpsDatabase::class.java,
            "wifi_wps_database"
        )
            .fallbackToDestructiveMigration()
            .build()
    }
    
    @Provides
    fun provideWifiNetworkDao(database: WifiWpsDatabase): WifiNetworkDao {
        return database.wifiNetworkDao()
    }
    
    @Provides
    fun provideWpsTestDao(database: WifiWpsDatabase): WpsTestDao {
        return database.wpsTestDao()
    }
}