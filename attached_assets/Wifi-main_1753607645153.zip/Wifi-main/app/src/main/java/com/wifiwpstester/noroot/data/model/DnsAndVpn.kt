package com.wifiwpstester.noroot.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "dns_test_results")
data class DnsTestResult(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val testTimestamp: Long,
    val dnsServer: String,
    val dnsProvider: DnsProvider,
    val queryDomain: String,
    val responseTimeMs: Long,
    val isSuccessful: Boolean,
    val resolvedIp: String?,
    val errorMessage: String? = null,
    val queryType: DnsQueryType,
    val ttl: Long = 0,
    val location: String
)

@Entity(tableName = "vpn_analysis_results")
data class VpnAnalysisResult(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val testTimestamp: Long,
    val vpnType: VpnType,
    val isVpnDetected: Boolean,
    val vpnProvider: String?,
    val serverLocation: String?,
    val realIpAddress: String,
    val vpnIpAddress: String?,
    val dnsLeakDetected: Boolean,
    val webRtcLeakDetected: Boolean,
    val ipv6LeakDetected: Boolean,
    val encryptionStrength: EncryptionStrength,
    val protocolUsed: VpnProtocol?,
    val latencyIncrease: Long,
    val speedReduction: Double,
    val privacyScore: Int // 0-100
)

@Entity(tableName = "dns_servers")
data class DnsServerInfo(
    @PrimaryKey
    val id: String,
    val serverAddress: String,
    val provider: DnsProvider,
    val country: String,
    val description: String,
    val isSecure: Boolean, // DNS over HTTPS/TLS
    val supportsFiltering: Boolean,
    val averageResponseTime: Long,
    val reliability: Double, // 0-100%
    val privacyRating: Int, // 1-5 stars
    val features: List<DnsFeature>
)

@Entity(tableName = "vpn_servers")
data class VpnServerInfo(
    @PrimaryKey
    val id: String,
    val serverName: String,
    val vpnProvider: String,
    val country: String,
    val city: String,
    val ipAddress: String,
    val vpnType: VpnType,
    val protocol: VpnProtocol,
    val port: Int,
    val isOnline: Boolean,
    val load: Int, // 0-100%
    val ping: Long,
    val bandwidth: Long, // Mbps
    val maxUsers: Int,
    val currentUsers: Int,
    val lastChecked: Long
)

enum class DnsProvider {
    GOOGLE,
    CLOUDFLARE,
    QUAD9,
    OPENDNS,
    ADGUARD,
    CLEAN_BROWSING,
    COMODO_SECURE,
    DNS_WATCH,
    YANDEX_DNS,
    ALTERNATE_DNS,
    CUSTOM,
    ISP_DEFAULT
}

enum class DnsQueryType {
    A_RECORD,
    AAAA_RECORD,
    MX_RECORD,
    TXT_RECORD,
    CNAME_RECORD,
    NS_RECORD,
    PTR_RECORD,
    SOA_RECORD
}

enum class DnsFeature {
    AD_BLOCKING,
    MALWARE_PROTECTION,
    FAMILY_FILTER,
    PHISHING_PROTECTION,
    DNS_OVER_HTTPS,
    DNS_OVER_TLS,
    ANYCAST,
    ZERO_LOGGING,
    FAST_RESPONSE,
    GEOGRAPHIC_BLOCKING
}

enum class VpnType {
    OPENVPN,      // Most common, highly secure
    WIREGUARD,    // Modern, fast, lightweight
    IKEV2_IPSEC,  // Mobile-friendly, auto-reconnect
    L2TP_IPSEC,   // Older but compatible
    PPTP          // Legacy, less secure but fast
}

enum class VpnProtocol {
    UDP,
    TCP,
    IKEV2,
    L2TP,
    PPTP,
    SSTP,
    WIREGUARD_UDP
}

enum class EncryptionStrength {
    NONE,
    WEAK_128,
    STANDARD_256,
    STRONG_256_PLUS,
    MILITARY_GRADE,
    UNKNOWN
}

data class DnsTestProgress(
    val currentServer: String,
    val serverIndex: Int,
    val totalServers: Int,
    val currentQuery: String,
    val phase: DnsTestPhase,
    val progress: Float
)

enum class DnsTestPhase {
    INITIALIZING,
    TESTING_SPEED,
    TESTING_RELIABILITY,
    TESTING_SECURITY,
    TESTING_FILTERING,
    ANALYZING_RESULTS,
    COMPLETED
}

data class VpnAnalysisProgress(
    val phase: VpnAnalysisPhase,
    val progress: Float,
    val currentTest: String,
    val testsCompleted: Int,
    val totalTests: Int
)

enum class VpnAnalysisPhase {
    DETECTING_VPN,
    CHECKING_IP_LEAKS,
    TESTING_DNS_LEAKS,
    ANALYZING_ENCRYPTION,
    MEASURING_PERFORMANCE,
    GENERATING_REPORT,
    COMPLETED
}

data class DnsSecurityAnalysis(
    val supportsDnssec: Boolean,
    val blocksAds: Boolean,
    val blocksMalware: Boolean,
    val blocksPhishing: Boolean,
    val logsPolicies: DnsLoggingPolicy,
    val supportsDoH: Boolean, // DNS over HTTPS
    val supportsDoT: Boolean, // DNS over TLS
    val securityScore: Int // 0-100
)

enum class DnsLoggingPolicy {
    NO_LOGS,
    MINIMAL_LOGS,
    STANDARD_LOGS,
    EXTENSIVE_LOGS,
    UNKNOWN
}

data class VpnPrivacyAnalysis(
    val masksRealIp: Boolean,
    val preventsIpLeaks: Boolean,
    val preventsDnsLeaks: Boolean,
    val preventsWebRtcLeaks: Boolean,
    val encryptsTraffic: Boolean,
    val killSwitchActive: Boolean,
    val noLoggingPolicy: Boolean,
    val jurisdictionSafe: Boolean,
    val privacyScore: Int // 0-100
)

data class NetworkLatencyTest(
    val targetHost: String,
    val minLatency: Long,
    val maxLatency: Long,
    val averageLatency: Long,
    val packetLoss: Double,
    val jitter: Long,
    val testCount: Int,
    val timestamp: Long
)

data class DnsBenchmarkResult(
    val fastestServer: DnsServerInfo,
    val slowestServer: DnsServerInfo,
    val averageResponseTime: Long,
    val reliabilityRanking: List<Pair<DnsServerInfo, Double>>,
    val securityRanking: List<Pair<DnsServerInfo, Int>>,
    val recommendedServer: DnsServerInfo
)

data class VpnPerformanceMetrics(
    val downloadSpeedWithoutVpn: Double,
    val downloadSpeedWithVpn: Double,
    val uploadSpeedWithoutVpn: Double,
    val uploadSpeedWithVpn: Double,
    val latencyWithoutVpn: Long,
    val latencyWithVpn: Long,
    val speedReductionPercentage: Double,
    val latencyIncrease: Long,
    val performanceRating: VpnPerformanceRating
)

enum class VpnPerformanceRating {
    EXCELLENT,    // < 10% speed reduction
    GOOD,         // 10-25% speed reduction
    ACCEPTABLE,   // 25-50% speed reduction
    POOR,         // 50-75% speed reduction
    VERY_POOR     // > 75% speed reduction
}