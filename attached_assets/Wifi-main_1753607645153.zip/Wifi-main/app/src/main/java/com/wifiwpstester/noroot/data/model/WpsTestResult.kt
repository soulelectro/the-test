package com.wifiwpstester.noroot.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wps_test_results")
data class WpsTestResult(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val networkBssid: String,
    val networkSsid: String,
    val testType: TestType,
    val result: TestResult,
    val pinsAttempted: List<String>,
    val successfulPin: String?,
    val timeStarted: Long,
    val timeCompleted: Long,
    val duration: Long,
    val riskLevel: RiskLevel,
    val notes: String = "",
    val isWpsLocked: Boolean = false,
    val lockoutDuration: Long = 0,
    val attemptsBeforeLockout: Int = 0
)

enum class TestType {
    DEFAULT_PINS,
    MANUAL_PIN,
    DICTIONARY_ATTACK,
    SEQUENTIAL_ATTACK,
    MANUFACTURER_SPECIFIC
}

enum class TestResult {
    SUCCESS,
    FAILED,
    WPS_LOCKED,
    TIMEOUT,
    CANCELLED,
    NETWORK_UNAVAILABLE,
    PERMISSION_DENIED
}

data class WpsPin(
    val pin: String,
    val description: String,
    val manufacturer: String? = null,
    val isDefault: Boolean = false,
    val priority: Int = 0
)

data class TestStatistics(
    val totalTests: Int,
    val successfulTests: Int,
    val failedTests: Int,
    val averageDuration: Long,
    val mostVulnerableManufacturer: String?,
    val riskDistribution: Map<RiskLevel, Int>
)