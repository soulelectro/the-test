package com.wifiwpstester.noroot.data.service

import android.content.Context
import android.net.ConnectivityManager
import android.net.wifi.WifiManager
import com.wifiwpstester.noroot.data.model.*
import com.wifiwpstester.noroot.data.repository.OfflineDataRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.math.*

@Singleton
class AiNetworkOptimizerService @Inject constructor(
    private val context: Context,
    private val offlineDataRepository: OfflineDataRepository
) {
    
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    private val _optimizationStatus = MutableStateFlow<NetworkOptimizationStatus>(NetworkOptimizationStatus.UNKNOWN)
    val optimizationStatus: StateFlow<NetworkOptimizationStatus> = _optimizationStatus.asStateFlow()
    
    private val _aiRecommendations = MutableStateFlow<List<AiRecommendation>>(emptyList())
    val aiRecommendations: StateFlow<List<AiRecommendation>> = _aiRecommendations.asStateFlow()
    
    private val _networkPredictions = MutableStateFlow<NetworkPredictions?>(null)
    val networkPredictions: StateFlow<NetworkPredictions?> = _networkPredictions.asStateFlow()
    
    private val _optimizationHistory = MutableStateFlow<List<OptimizationEvent>>(emptyList())
    val optimizationHistory: StateFlow<List<OptimizationEvent>> = _optimizationHistory.asStateFlow()
    
    // AI Model Data (stored locally, no cloud ML required)
    private val speedPatterns = mutableMapOf<Int, List<SpeedDataPoint>>() // Hour -> Speed data
    private val signalPatterns = mutableMapOf<String, List<SignalDataPoint>>() // Location -> Signal data
    private val usagePatterns = mutableMapOf<String, Double>() // App -> Bandwidth usage
    
    data class NetworkOptimizationStatus(
        val overallScore: Int, // 0-100
        val status: OptimizationLevel,
        val primaryIssue: String?,
        val potentialImprovement: String?,
        val lastAnalysis: Long = System.currentTimeMillis(),
        val confidence: Double = 0.0
    ) {
        companion object {
            val UNKNOWN = NetworkOptimizationStatus(
                overallScore = 0,
                status = OptimizationLevel.UNKNOWN,
                primaryIssue = null,
                potentialImprovement = null,
                confidence = 0.0
            )
        }
    }
    
    enum class OptimizationLevel {
        EXCELLENT,     // 90-100
        GOOD,          // 70-89  
        NEEDS_TUNING,  // 50-69
        POOR,          // 30-49
        CRITICAL,      // 0-29
        UNKNOWN
    }
    
    data class AiRecommendation(
        val id: String,
        val type: RecommendationType,
        val title: String,
        val description: String,
        val impact: ImpactLevel,
        val confidence: Double,
        val estimatedImprovement: String,
        val actionRequired: String,
        val priority: Int,
        val isApplicable: Boolean = true,
        val timestamp: Long = System.currentTimeMillis()
    )
    
    enum class RecommendationType {
        DNS_OPTIMIZATION,
        WIFI_CHANNEL,
        SIGNAL_POSITION,
        TIME_BASED,
        APP_MANAGEMENT,
        VPN_ROUTING,
        MULTI_CONNECTION,
        HARDWARE_UPGRADE
    }
    
    enum class ImpactLevel {
        HIGH,      // >30% improvement
        MEDIUM,    // 10-30% improvement  
        LOW        // 5-10% improvement
    }
    
    data class NetworkPredictions(
        val peakHours: List<Int>,
        val bestPerformanceTime: Int,
        val worstPerformanceTime: Int,
        val predictedSpeedAt: Map<Int, Double>, // Hour -> Predicted speed
        val congestionForecast: List<CongestionPrediction>,
        val optimalSettings: OptimalNetworkSettings,
        val confidence: Double
    )
    
    data class CongestionPrediction(
        val hour: Int,
        val congestionLevel: CongestionLevel,
        val affectedBands: List<String>,
        val recommendedAction: String
    )
    
    enum class CongestionLevel {
        LOW, MEDIUM, HIGH, SEVERE
    }
    
    data class OptimalNetworkSettings(
        val recommendedDns: String,
        val preferredBand: String, // 2.4GHz, 5GHz, or Auto
        val optimalChannel: Int,
        val useVpn: Boolean,
        val enableMultipath: Boolean
    )
    
    data class OptimizationEvent(
        val timestamp: Long,
        val action: String,
        val result: String,
        val improvement: Double,
        val confidence: Double
    )
    
    data class SpeedDataPoint(
        val timestamp: Long,
        val speed: Double,
        val networkType: NetworkType,
        val signalStrength: Int
    )
    
    data class SignalDataPoint(
        val timestamp: Long,
        val rssi: Int,
        val frequency: Int,
        val channel: Int
    )
    
    init {
        startAiAnalysis()
        initializeAiModels()
    }
    
    private fun initializeAiModels() {
        scope.launch {
            // Initialize with sample data for demonstration
            generateSampleTrainingData()
            trainSpeedPredictionModel()
            trainSignalOptimizationModel()
        }
    }
    
    private fun generateSampleTrainingData() {
        // Generate realistic network performance patterns
        for (hour in 0..23) {
            val speedData = mutableListOf<SpeedDataPoint>()
            
            // Model typical usage patterns
            val baseSpeed = when (hour) {
                in 2..6 -> 80.0 + Random().nextGaussian() * 10  // Night - less congestion
                in 7..9 -> 45.0 + Random().nextGaussian() * 15  // Morning peak
                in 10..16 -> 60.0 + Random().nextGaussian() * 12 // Day
                in 17..22 -> 35.0 + Random().nextGaussian() * 18 // Evening peak
                else -> 50.0 + Random().nextGaussian() * 10      // Late night
            }
            
            repeat(30) { // 30 data points per hour
                speedData.add(SpeedDataPoint(
                    timestamp = System.currentTimeMillis() - (hour * 3600000L),
                    speed = maxOf(5.0, baseSpeed + Random().nextGaussian() * 5),
                    networkType = if (Random().nextBoolean()) NetworkType.WIFI else NetworkType.MOBILE_4G,
                    signalStrength = -40 - Random().nextInt(40)
                ))
            }
            
            speedPatterns[hour] = speedData
        }
    }
    
    private fun trainSpeedPredictionModel() {
        // Simple linear regression model for speed prediction
        // In a real implementation, this could use TensorFlow Lite or similar
        
        val predictions = mutableMapOf<Int, Double>()
        
        speedPatterns.forEach { (hour, dataPoints) ->
            val avgSpeed = dataPoints.map { it.speed }.average()
            val trend = calculateTrend(dataPoints)
            
            // Predict speed with trend analysis
            predictions[hour] = maxOf(5.0, avgSpeed + trend * 0.1)
        }
        
        // Update predictions
        val peakHours = speedPatterns.entries
            .sortedByDescending { it.value.map { dp -> dp.speed }.average() }
            .take(3)
            .map { it.key }
        
        val bestTime = speedPatterns.maxByOrNull { it.value.map { dp -> dp.speed }.average() }?.key ?: 3
        val worstTime = speedPatterns.minByOrNull { it.value.map { dp -> dp.speed }.average() }?.key ?: 19
        
        _networkPredictions.value = NetworkPredictions(
            peakHours = peakHours,
            bestPerformanceTime = bestTime,
            worstPerformanceTime = worstTime,
            predictedSpeedAt = predictions,
            congestionForecast = generateCongestionForecast(),
            optimalSettings = calculateOptimalSettings(),
            confidence = 0.85
        )
    }
    
    private fun calculateTrend(dataPoints: List<SpeedDataPoint>): Double {
        if (dataPoints.size < 2) return 0.0
        
        val sortedPoints = dataPoints.sortedBy { it.timestamp }
        val firstHalf = sortedPoints.take(sortedPoints.size / 2).map { it.speed }.average()
        val secondHalf = sortedPoints.takeLast(sortedPoints.size / 2).map { it.speed }.average()
        
        return secondHalf - firstHalf
    }
    
    private fun generateCongestionForecast(): List<CongestionPrediction> {
        val forecast = mutableListOf<CongestionPrediction>()
        
        for (hour in 0..23) {
            val congestionLevel = when (hour) {
                in 7..9, in 17..22 -> CongestionLevel.HIGH
                in 10..16 -> CongestionLevel.MEDIUM
                in 23..1 -> CongestionLevel.LOW
                else -> CongestionLevel.LOW
            }
            
            forecast.add(CongestionPrediction(
                hour = hour,
                congestionLevel = congestionLevel,
                affectedBands = if (congestionLevel == CongestionLevel.HIGH) listOf("2.4GHz") else emptyList(),
                recommendedAction = when (congestionLevel) {
                    CongestionLevel.HIGH -> "Switch to 5GHz or use mobile data"
                    CongestionLevel.MEDIUM -> "Consider 5GHz if available"
                    else -> "Current settings optimal"
                }
            ))
        }
        
        return forecast
    }
    
    private fun calculateOptimalSettings(): OptimalNetworkSettings {
        return OptimalNetworkSettings(
            recommendedDns = "1.1.1.1", // Cloudflare - generally fastest
            preferredBand = "5GHz",
            optimalChannel = 36, // Less congested 5GHz channel
            useVpn = false, // Unless privacy is needed
            enableMultipath = true
        )
    }
    
    private fun trainSignalOptimizationModel() {
        // Generate signal strength recommendations based on location patterns
        val locations = listOf("living_room", "bedroom", "kitchen", "office")
        
        locations.forEach { location ->
            val signalData = mutableListOf<SignalDataPoint>()
            val baseRssi = -45 - Random().nextInt(30) // Vary by location
            
            repeat(50) {
                signalData.add(SignalDataPoint(
                    timestamp = System.currentTimeMillis() - Random().nextLong() % 86400000,
                    rssi = baseRssi + Random().nextInt(20) - 10,
                    frequency = if (Random().nextBoolean()) 2437 else 5180,
                    channel = if (Random().nextBoolean()) 6 else 36
                ))
            }
            
            signalPatterns[location] = signalData
        }
    }
    
    fun startAiAnalysis() {
        scope.launch {
            while (true) {
                performAiAnalysis()
                delay(60000) // Analyze every minute
            }
        }
    }
    
    private suspend fun performAiAnalysis() {
        try {
            // Gather current network data
            val currentSpeed = getCurrentNetworkSpeed()
            val currentSignal = getCurrentSignalStrength()
            val currentTime = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            
            // Generate AI recommendations
            val recommendations = generateAiRecommendations(currentSpeed, currentSignal, currentTime)
            _aiRecommendations.value = recommendations.sortedByDescending { it.priority }
            
            // Calculate overall optimization score
            val optimizationScore = calculateOptimizationScore(currentSpeed, currentSignal, recommendations)
            
            _optimizationStatus.value = NetworkOptimizationStatus(
                overallScore = optimizationScore,
                status = getOptimizationLevel(optimizationScore),
                primaryIssue = findPrimaryIssue(recommendations),
                potentialImprovement = calculatePotentialImprovement(recommendations),
                confidence = 0.8
            )
            
        } catch (e: Exception) {
            // Handle analysis errors gracefully
        }
    }
    
    private fun getCurrentNetworkSpeed(): Double {
        // In a real implementation, this would get actual speed data
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return speedPatterns[currentHour]?.lastOrNull()?.speed ?: 50.0
    }
    
    private fun getCurrentSignalStrength(): Int {
        // In a real implementation, this would get actual signal strength
        return -50 - Random().nextInt(30)
    }
    
    private fun generateAiRecommendations(speed: Double, signal: Int, hour: Int): List<AiRecommendation> {
        val recommendations = mutableListOf<AiRecommendation>()
        
        // DNS Optimization Recommendation
        if (speed < 30) {
            recommendations.add(AiRecommendation(
                id = "dns_opt_${System.currentTimeMillis()}",
                type = RecommendationType.DNS_OPTIMIZATION,
                title = "Optimize DNS Settings",
                description = "Your current DNS server is responding slowly. Switching to a faster DNS can improve browsing speed.",
                impact = ImpactLevel.MEDIUM,
                confidence = 0.9,
                estimatedImprovement = "20-30% faster page loading",
                actionRequired = "Switch to Cloudflare DNS (1.1.1.1)",
                priority = 8
            ))
        }
        
        // Signal Position Recommendation
        if (signal < -70) {
            recommendations.add(AiRecommendation(
                id = "signal_pos_${System.currentTimeMillis()}",
                type = RecommendationType.SIGNAL_POSITION,
                title = "Improve Signal Strength",
                description = "Your WiFi signal is weak. Moving closer to the router or removing obstacles can significantly improve performance.",
                impact = ImpactLevel.HIGH,
                confidence = 0.95,
                estimatedImprovement = "40-60% speed increase",
                actionRequired = "Move closer to router or remove obstacles",
                priority = 9
            ))
        }
        
        // Time-based Recommendation
        if (hour in 17..22) { // Peak hours
            recommendations.add(AiRecommendation(
                id = "time_based_${System.currentTimeMillis()}",
                type = RecommendationType.TIME_BASED,
                title = "Peak Hour Detected",
                description = "Network congestion is high during evening hours. Consider using mobile data for critical tasks.",
                impact = ImpactLevel.MEDIUM,
                confidence = 0.85,
                estimatedImprovement = "Consistent performance during peak hours",
                actionRequired = "Switch to mobile data or schedule heavy downloads for off-peak hours",
                priority = 6
            ))
        }
        
        // WiFi Channel Recommendation
        if (signal > -60 && speed < 40) {
            recommendations.add(AiRecommendation(
                id = "wifi_channel_${System.currentTimeMillis()}",
                type = RecommendationType.WIFI_CHANNEL,
                title = "WiFi Channel Congestion",
                description = "Your WiFi channel appears congested. Switching to 5GHz or a less crowded channel can improve speeds.",
                impact = ImpactLevel.HIGH,
                confidence = 0.8,
                estimatedImprovement = "30-50% speed improvement",
                actionRequired = "Switch to 5GHz band or change WiFi channel",
                priority = 7
            ))
        }
        
        // Multi-connection Recommendation
        if (speed < 20) {
            recommendations.add(AiRecommendation(
                id = "multi_conn_${System.currentTimeMillis()}",
                type = RecommendationType.MULTI_CONNECTION,
                title = "Enable Multi-Connection",
                description = "Combining WiFi and mobile data can provide better performance when individual connections are slow.",
                impact = ImpactLevel.MEDIUM,
                confidence = 0.7,
                estimatedImprovement = "25-40% combined speed boost",
                actionRequired = "Enable WiFi + Mobile data bonding",
                priority = 5
            ))
        }
        
        // VPN Routing Recommendation
        if (speed > 50 && signal > -50) {
            recommendations.add(AiRecommendation(
                id = "vpn_routing_${System.currentTimeMillis()}",
                type = RecommendationType.VPN_ROUTING,
                title = "VPN Acceleration Available",
                description = "Your connection is strong enough to benefit from VPN acceleration services like Cloudflare Warp.",
                impact = ImpactLevel.LOW,
                confidence = 0.6,
                estimatedImprovement = "10-15% speed boost with better routing",
                actionRequired = "Enable Cloudflare Warp or similar service",
                priority = 3
            ))
        }
        
        return recommendations
    }
    
    private fun calculateOptimizationScore(speed: Double, signal: Int, recommendations: List<AiRecommendation>): Int {
        var score = 50 // Base score
        
        // Speed component (0-40 points)
        score += when {
            speed >= 100 -> 40
            speed >= 50 -> 30
            speed >= 25 -> 20
            speed >= 10 -> 10
            else -> 0
        }
        
        // Signal component (0-30 points)
        score += when {
            signal >= -30 -> 30
            signal >= -50 -> 25
            signal >= -70 -> 15
            signal >= -80 -> 5
            else -> 0
        }
        
        // Penalty for critical issues (0-20 points deduction)
        val criticalIssues = recommendations.count { it.impact == ImpactLevel.HIGH }
        score -= criticalIssues * 10
        
        return maxOf(0, minOf(100, score))
    }
    
    private fun getOptimizationLevel(score: Int): OptimizationLevel {
        return when (score) {
            in 90..100 -> OptimizationLevel.EXCELLENT
            in 70..89 -> OptimizationLevel.GOOD
            in 50..69 -> OptimizationLevel.NEEDS_TUNING
            in 30..49 -> OptimizationLevel.POOR
            in 0..29 -> OptimizationLevel.CRITICAL
            else -> OptimizationLevel.UNKNOWN
        }
    }
    
    private fun findPrimaryIssue(recommendations: List<AiRecommendation>): String? {
        return recommendations
            .filter { it.impact == ImpactLevel.HIGH }
            .maxByOrNull { it.confidence }
            ?.title
    }
    
    private fun calculatePotentialImprovement(recommendations: List<AiRecommendation>): String? {
        val highImpactRecs = recommendations.filter { it.impact == ImpactLevel.HIGH }
        if (highImpactRecs.isEmpty()) return null
        
        return "Up to ${highImpactRecs.size * 30}% performance improvement possible"
    }
    
    fun applyRecommendation(recommendationId: String) {
        scope.launch {
            val recommendation = _aiRecommendations.value.find { it.id == recommendationId }
            if (recommendation != null) {
                // Simulate applying the recommendation
                val event = OptimizationEvent(
                    timestamp = System.currentTimeMillis(),
                    action = recommendation.title,
                    result = "Applied successfully",
                    improvement = when (recommendation.impact) {
                        ImpactLevel.HIGH -> 35.0
                        ImpactLevel.MEDIUM -> 20.0
                        ImpactLevel.LOW -> 10.0
                    },
                    confidence = recommendation.confidence
                )
                
                val currentHistory = _optimizationHistory.value.toMutableList()
                currentHistory.add(0, event) // Add to beginning
                _optimizationHistory.value = currentHistory.take(50) // Keep last 50 events
                
                // Re-run analysis after applying recommendation
                delay(2000)
                performAiAnalysis()
            }
        }
    }
    
    fun getPredictedPerformance(targetHour: Int): Double? {
        return _networkPredictions.value?.predictedSpeedAt?.get(targetHour)
    }
    
    fun getOptimalTimeForActivity(activityType: ActivityType): Int? {
        val predictions = _networkPredictions.value ?: return null
        
        return when (activityType) {
            ActivityType.STREAMING -> predictions.bestPerformanceTime
            ActivityType.GAMING -> predictions.predictedSpeedAt.entries
                .filter { it.value > 30 && it.key !in 17..22 } // Good speed, not peak hours
                .minByOrNull { abs(it.key - 20) }?.key // Prefer evening but not peak
            ActivityType.DOWNLOADING -> predictions.bestPerformanceTime
            ActivityType.VIDEO_CALLS -> predictions.predictedSpeedAt.entries
                .filter { it.value > 20 }
                .minByOrNull { predictions.congestionForecast.find { cf -> cf.hour == it.key }?.congestionLevel?.ordinal ?: 0 }?.key
        }
    }
    
    enum class ActivityType {
        STREAMING, GAMING, DOWNLOADING, VIDEO_CALLS
    }
    
    fun getNetworkHealthScore(): Int {
        return _optimizationStatus.value.overallScore
    }
    
    fun clearOptimizationHistory() {
        _optimizationHistory.value = emptyList()
    }
}