package com.wifiwpstester.noroot.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.wifiwpstester.noroot.ui.theme.WifiWpsTesterTheme

class DisclaimerActivity : ComponentActivity() {
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        setContent {
            WifiWpsTesterTheme {
                DisclaimerScreen(
                    onAccept = {
                        // Save acceptance and proceed to main app
                        val sharedPrefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
                        sharedPrefs.edit().putBoolean("agreed_to_terms", true).apply()
                        
                        startActivity(Intent(this@DisclaimerActivity, MainActivity::class.java))
                        finish()
                    },
                    onDecline = {
                        finish()
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DisclaimerScreen(
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    var hasReadTerms by remember { mutableStateOf(false) }
    var agreeToTerms by remember { mutableStateOf(false) }
    
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "WiFi WPS Tester – No Root",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Security Testing & Educational Tool",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                        textAlign = TextAlign.Center
                    )
                }
            }
            
            // Terms and conditions
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Legal Disclaimer & Terms of Use",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    
                    Text(
                        text = """
                        🔒 EDUCATIONAL AND AUTHORIZED TESTING ONLY
                        
                        This application is designed for educational purposes and authorized security testing only. By using this app, you acknowledge and agree to the following terms:
                        
                        ✅ PERMITTED USES:
                        • Testing your own WiFi networks
                        • Educational learning about WiFi security
                        • Authorized penetration testing with written permission
                        • Security research in controlled environments
                        
                        ❌ PROHIBITED USES:
                        • Testing networks without explicit permission
                        • Unauthorized access to any network
                        • Any illegal or malicious activities
                        • Commercial use without proper licensing
                        
                        🛡️ OFFLINE FUNCTIONALITY:
                        • This app works completely offline
                        • No data is sent to external servers
                        • All databases and PINs are stored locally
                        • Your privacy is fully protected
                        
                        ⚖️ LEGAL RESPONSIBILITY:
                        • You are solely responsible for your actions
                        • The developers are not liable for misuse
                        • Comply with all local and international laws
                        • Use only on networks you own or have permission to test
                        
                        🔐 TECHNICAL LIMITATIONS:
                        • No root access required or used
                        • Uses only standard Android APIs
                        • Educational simulation of WPS testing
                        • Results are for learning purposes
                        
                        🌍 COMPLIANCE:
                        • This app complies with Google Play policies
                        • Designed for security professionals and students
                        • Promotes responsible security research
                        • Encourages ethical hacking practices
                        
                        By proceeding, you confirm that you:
                        1. Are at least 18 years old or have parental consent
                        2. Will use this app only for legal purposes
                        3. Have permission to test any networks you scan
                        4. Understand the educational nature of this tool
                        5. Accept full responsibility for your actions
                        
                        REMEMBER: Unauthorized network access is illegal in most jurisdictions and may result in criminal charges.
                        """.trimIndent(),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                    
                    LaunchedEffect(Unit) {
                        kotlinx.coroutines.delay(3000) // Force user to read for at least 3 seconds
                        hasReadTerms = true
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Checkbox for agreement
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = agreeToTerms,
                    onCheckedChange = { agreeToTerms = it },
                    enabled = hasReadTerms
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "I have read and agree to the terms above. I confirm that I will only test networks I own or have explicit permission to test.",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.weight(1f)
                )
            }
            
            Spacer(modifier = Modifier.height(16.dp))
            
            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                OutlinedButton(
                    onClick = onDecline,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Decline")
                }
                
                Button(
                    onClick = onAccept,
                    enabled = hasReadTerms && agreeToTerms,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Accept & Continue")
                }
            }
        }
    }
}