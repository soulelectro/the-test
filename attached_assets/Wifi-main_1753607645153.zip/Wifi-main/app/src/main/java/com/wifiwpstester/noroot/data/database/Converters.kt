package com.wifiwpstester.noroot.data.database

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.wifiwpstester.noroot.data.model.*

class Converters {
    
    @TypeConverter
    fun fromSecurityType(value: SecurityType): String = value.name
    
    @TypeConverter
    fun toSecurityType(value: String): SecurityType = SecurityType.valueOf(value)
    
    @TypeConverter
    fun fromRiskLevel(value: RiskLevel): String = value.name
    
    @TypeConverter
    fun toRiskLevel(value: String): RiskLevel = RiskLevel.valueOf(value)
    
    @TypeConverter
    fun fromTestType(value: TestType): String = value.name
    
    @TypeConverter
    fun toTestType(value: String): TestType = TestType.valueOf(value)
    
    @TypeConverter
    fun fromTestResult(value: TestResult): String = value.name
    
    @TypeConverter
    fun toTestResult(value: String): TestResult = TestResult.valueOf(value)
    
    @TypeConverter
    fun fromStringList(value: List<String>): String {
        return Gson().toJson(value)
    }
    
    @TypeConverter
    fun toStringList(value: String): List<String> {
        val listType = object : TypeToken<List<String>>() {}.type
        return Gson().fromJson(value, listType) ?: emptyList()
    }
    
    @TypeConverter
    fun fromRiskDistributionMap(value: Map<RiskLevel, Int>): String {
        return Gson().toJson(value)
    }
    
    @TypeConverter
    fun toRiskDistributionMap(value: String): Map<RiskLevel, Int> {
        val mapType = object : TypeToken<Map<RiskLevel, Int>>() {}.type
        return Gson().fromJson(value, mapType) ?: emptyMap()
    }
}