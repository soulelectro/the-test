package com.wifiwpstester.noroot.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.wifiwpstester.noroot.data.model.*
import com.wifiwpstester.noroot.ui.viewmodel.MainViewModel
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiScannerScreen(
    viewModel: MainViewModel
) {
    val scanResults by viewModel.scanResults.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()
    val scanError by viewModel.scanError.collectAsState()
    val allNetworks by viewModel.allNetworks.collectAsState()
    
    var showWpsOnly by remember { mutableStateOf(false) }
    var sortBy by remember { mutableStateOf(SortOption.SIGNAL_STRENGTH) }
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Dashboard Cards
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            DashboardCard(
                title = "Total Networks",
                value = scanResults?.totalNetworks?.toString() ?: allNetworks.size.toString(),
                icon = Icons.Default.Wifi,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.weight(1f)
            )
            
            DashboardCard(
                title = "WPS Enabled",
                value = scanResults?.wpsEnabledCount?.toString() ?: allNetworks.count { it.isWpsEnabled }.toString(),
                icon = Icons.Default.Security,
                color = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.weight(1f)
            )
            
            DashboardCard(
                title = "Vulnerable",
                value = scanResults?.vulnerableCount?.toString() ?: allNetworks.count { 
                    viewModel.getRiskLevel(it) in listOf(RiskLevel.HIGH, RiskLevel.CRITICAL)
                }.toString(),
                icon = Icons.Default.Warning,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.weight(1f)
            )
        }
        
        // Control Panel
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                // Scan Button
                Button(
                    onClick = { viewModel.startWifiScan() },
                    enabled = !isScanning,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (isScanning) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Scanning...")
                    } else {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Start WiFi Scan")
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                
                // Filter Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = showWpsOnly,
                            onCheckedChange = { showWpsOnly = it }
                        )
                        Text(
                            text = "WPS Only",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    
                    // Sort Dropdown
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded }
                    ) {
                        OutlinedTextField(
                            readOnly = true,
                            value = sortBy.displayName,
                            onValueChange = { },
                            label = { Text("Sort by") },
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                            },
                            modifier = Modifier
                                .menuAnchor()
                                .width(140.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            SortOption.values().forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(option.displayName) },
                                    onClick = {
                                        sortBy = option
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
        
        // Error Display
        scanError?.let { error ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer
                )
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Error,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onErrorContainer
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = error,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = { viewModel.clearScanError() }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss",
                            tint = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }
        
        // Networks List
        val networksToShow = remember(scanResults, allNetworks, showWpsOnly, sortBy) {
            val networks = scanResults?.networks ?: allNetworks
            val filtered = if (showWpsOnly) {
                networks.filter { it.isWpsEnabled }
            } else {
                networks
            }
            
            when (sortBy) {
                SortOption.SIGNAL_STRENGTH -> filtered.sortedByDescending { it.rssi }
                SortOption.SSID -> filtered.sortedBy { it.ssid }
                SortOption.SECURITY -> filtered.sortedBy { it.securityType.name }
                SortOption.RISK_LEVEL -> filtered.sortedByDescending { 
                    viewModel.getRiskLevel(it).ordinal 
                }
            }
        }
        
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(networksToShow) { network ->
                NetworkCard(
                    network = network,
                    viewModel = viewModel,
                    onClick = { viewModel.selectNetwork(network) }
                )
            }
        }
    }
}

@Composable
fun DashboardCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.1f)
        )
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = color
            )
            Text(
                text = title,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkCard(
    network: WifiNetwork,
    viewModel: MainViewModel,
    onClick: () -> Unit
) {
    val riskLevel = viewModel.getRiskLevel(network)
    val manufacturerName = viewModel.getManufacturerName(network)
    
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when (riskLevel) {
                RiskLevel.CRITICAL -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                RiskLevel.HIGH -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)
                RiskLevel.MEDIUM -> MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.2f)
                RiskLevel.LOW -> MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = network.ssid.ifEmpty { "Hidden Network" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = network.bssid,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                
                // Signal Strength
                SignalStrengthIndicator(
                    rssi = network.rssi,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            // Info Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Security Type
                SecurityChip(
                    securityType = network.securityType,
                    modifier = Modifier.weight(1f)
                )
                
                // WPS Status
                if (network.isWpsEnabled) {
                    WpsChip(
                        riskLevel = riskLevel,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            
            if (manufacturerName != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Business,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = manufacturerName,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            
            // Risk Level Indicator
            if (riskLevel != RiskLevel.LOW) {
                Spacer(modifier = Modifier.height(8.dp))
                RiskLevelIndicator(riskLevel = riskLevel)
            }
        }
    }
}

@Composable
fun SignalStrengthIndicator(
    rssi: Int,
    modifier: Modifier = Modifier
) {
    val strength = when {
        rssi >= -50 -> 4
        rssi >= -60 -> 3
        rssi >= -70 -> 2
        rssi >= -80 -> 1
        else -> 0
    }
    
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.Bottom,
        horizontalArrangement = Arrangement.spacedBy(1.dp)
    ) {
        repeat(4) { index ->
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height((8 + index * 3).dp)
                    .clip(RoundedCornerShape(1.dp))
                    .then(
                        if (index < strength) {
                            Modifier.background(
                                when {
                                    strength >= 3 -> MaterialTheme.colorScheme.primary
                                    strength >= 2 -> MaterialTheme.colorScheme.tertiary
                                    else -> MaterialTheme.colorScheme.error
                                }
                            )
                        } else {
                            Modifier.background(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                        }
                    )
            )
        }
    }
}

@Composable
fun SecurityChip(
    securityType: SecurityType,
    modifier: Modifier = Modifier
) {
    val (color, text) = when (securityType) {
        SecurityType.OPEN -> MaterialTheme.colorScheme.error to "Open"
        SecurityType.WEP -> MaterialTheme.colorScheme.error to "WEP"
        SecurityType.WPA -> MaterialTheme.colorScheme.tertiary to "WPA"
        SecurityType.WPA2 -> MaterialTheme.colorScheme.primary to "WPA2"
        SecurityType.WPA3 -> MaterialTheme.colorScheme.secondary to "WPA3"
        SecurityType.WPA_WPA2 -> MaterialTheme.colorScheme.primary to "WPA/WPA2"
        SecurityType.WPA2_WPA3 -> MaterialTheme.colorScheme.secondary to "WPA2/WPA3"
        SecurityType.UNKNOWN -> MaterialTheme.colorScheme.outline to "Unknown"
    }
    
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = color.copy(alpha = 0.2f)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = color
        )
    }
}

@Composable
fun WpsChip(
    riskLevel: RiskLevel,
    modifier: Modifier = Modifier
) {
    val (color, text) = when (riskLevel) {
        RiskLevel.CRITICAL -> MaterialTheme.colorScheme.error to "WPS Critical"
        RiskLevel.HIGH -> MaterialTheme.colorScheme.error to "WPS High Risk"
        RiskLevel.MEDIUM -> MaterialTheme.colorScheme.tertiary to "WPS Medium"
        RiskLevel.LOW -> MaterialTheme.colorScheme.outline to "WPS Low"
    }
    
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = color.copy(alpha = 0.2f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                modifier = Modifier.size(12.dp),
                tint = color
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.labelSmall,
                color = color
            )
        }
    }
}

@Composable
fun RiskLevelIndicator(
    riskLevel: RiskLevel,
    modifier: Modifier = Modifier
) {
    val (color, text, icon) = when (riskLevel) {
        RiskLevel.CRITICAL -> Triple(
            MaterialTheme.colorScheme.error,
            "Critical Risk - Immediate attention required",
            Icons.Default.Dangerous
        )
        RiskLevel.HIGH -> Triple(
            MaterialTheme.colorScheme.error,
            "High Risk - Security concerns detected",
            Icons.Default.Warning
        )
        RiskLevel.MEDIUM -> Triple(
            MaterialTheme.colorScheme.tertiary,
            "Medium Risk - Review security settings",
            Icons.Default.Info
        )
        RiskLevel.LOW -> Triple(
            MaterialTheme.colorScheme.outline,
            "Low Risk",
            Icons.Default.CheckCircle
        )
    }
    
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(16.dp),
            tint = color
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = color
        )
    }
}

enum class SortOption(val displayName: String) {
    SIGNAL_STRENGTH("Signal Strength"),
    SSID("Network Name"),
    SECURITY("Security Type"),
    RISK_LEVEL("Risk Level")
}