package com.wifiwpstester.noroot.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wifi_networks")
data class WifiNetwork(
    @PrimaryKey
    val bssid: String,
    val ssid: String,
    val rssi: Int,
    val frequency: Int,
    val capabilities: String,
    val isWpsEnabled: Boolean,
    val securityType: SecurityType,
    val manufacturerOui: String?,
    val lastSeen: Long = System.currentTimeMillis(),
    val channel: Int = 0,
    val centerFreq0: Int = 0,
    val centerFreq1: Int = 0,
    val channelWidth: Int = 0
)

enum class SecurityType {
    OPEN,
    WEP,
    WPA,
    WPA2,
    WPA3,
    WPA_WPA2,
    WPA2_WPA3,
    UNKNOWN
}

enum class RiskLevel {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

data class NetworkScanResult(
    val networks: List<WifiNetwork>,
    val scanTime: Long,
    val totalNetworks: Int,
    val wpsEnabledCount: Int,
    val vulnerableCount: Int
)