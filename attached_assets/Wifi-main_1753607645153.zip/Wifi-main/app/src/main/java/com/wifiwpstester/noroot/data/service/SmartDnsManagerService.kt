package com.wifiwpstester.noroot.data.service

import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.wifi.WifiManager
import android.os.Build
import androidx.annotation.RequiresApi
import com.wifiwpstester.noroot.data.model.*
import com.wifiwpstester.noroot.data.repository.OfflineDataRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.IOException
import java.net.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SmartDnsManagerService @Inject constructor(
    private val context: Context,
    private val offlineDataRepository: OfflineDataRepository
) {
    
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val wifiManager = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    private val _currentDnsServers = MutableStateFlow<List<String>>(emptyList())
    val currentDnsServers: StateFlow<List<String>> = _currentDnsServers.asStateFlow()
    
    private val _dnsTestResults = MutableStateFlow<List<DnsTestResult>>(emptyList())
    val dnsTestResults: StateFlow<List<DnsTestResult>> = _dnsTestResults.asStateFlow()
    
    private val _dnsTestProgress = MutableStateFlow<DnsTestProgress?>(null)
    val dnsTestProgress: StateFlow<DnsTestProgress?> = _dnsTestProgress.asStateFlow()
    
    private val _recommendedDns = MutableStateFlow<DnsServerInfo?>(null)
    val recommendedDns: StateFlow<DnsServerInfo?> = _recommendedDns.asStateFlow()
    
    private val _dnsOptimizationStatus = MutableStateFlow<DnsOptimizationStatus>(DnsOptimizationStatus.UNKNOWN)
    val dnsOptimizationStatus: StateFlow<DnsOptimizationStatus> = _dnsOptimizationStatus.asStateFlow()
    
    data class DnsOptimizationStatus(
        val status: OptimizationStatus,
        val currentLatency: Long,
        val potentialImprovement: Long,
        val recommendation: String,
        val lastChecked: Long = System.currentTimeMillis()
    )
    
    enum class OptimizationStatus {
        OPTIMIZED,
        NEEDS_FIXING,
        TESTING,
        UNKNOWN
    }
    
    companion object {
        val UNKNOWN = DnsOptimizationStatus(
            status = OptimizationStatus.UNKNOWN,
            currentLatency = 0,
            potentialImprovement = 0,
            recommendation = "Analyzing DNS configuration..."
        )
    }
    
    init {
        detectCurrentDnsServers()
        startPeriodicDnsMonitoring()
    }
    
    fun getPublicDnsServers(): List<DnsServerInfo> {
        return listOf(
            // Cloudflare DNS
            DnsServerInfo(
                id = "cloudflare_primary",
                serverAddress = "1.1.1.1",
                provider = DnsProvider.CLOUDFLARE,
                country = "Global",
                description = "Cloudflare DNS - Privacy focused, fast",
                isSecure = true,
                supportsFiltering = false,
                averageResponseTime = 15,
                reliability = 99.9,
                privacyRating = 5,
                features = listOf(
                    DnsFeature.DNS_OVER_HTTPS,
                    DnsFeature.DNS_OVER_TLS,
                    DnsFeature.ZERO_LOGGING,
                    DnsFeature.FAST_RESPONSE,
                    DnsFeature.ANYCAST
                )
            ),
            DnsServerInfo(
                id = "cloudflare_secondary",
                serverAddress = "1.0.0.1",
                provider = DnsProvider.CLOUDFLARE,
                country = "Global",
                description = "Cloudflare DNS Secondary",
                isSecure = true,
                supportsFiltering = false,
                averageResponseTime = 16,
                reliability = 99.9,
                privacyRating = 5,
                features = listOf(
                    DnsFeature.DNS_OVER_HTTPS,
                    DnsFeature.DNS_OVER_TLS,
                    DnsFeature.ZERO_LOGGING,
                    DnsFeature.FAST_RESPONSE
                )
            ),
            
            // Google DNS
            DnsServerInfo(
                id = "google_primary",
                serverAddress = "8.8.8.8",
                provider = DnsProvider.GOOGLE,
                country = "Global",
                description = "Google Public DNS - Reliable, fast",
                isSecure = true,
                supportsFiltering = false,
                averageResponseTime = 20,
                reliability = 99.8,
                privacyRating = 3,
                features = listOf(
                    DnsFeature.DNS_OVER_HTTPS,
                    DnsFeature.DNS_OVER_TLS,
                    DnsFeature.FAST_RESPONSE,
                    DnsFeature.ANYCAST
                )
            ),
            DnsServerInfo(
                id = "google_secondary",
                serverAddress = "8.8.4.4",
                provider = DnsProvider.GOOGLE,
                country = "Global",
                description = "Google Public DNS Secondary",
                isSecure = true,
                supportsFiltering = false,
                averageResponseTime = 22,
                reliability = 99.8,
                privacyRating = 3,
                features = listOf(
                    DnsFeature.DNS_OVER_HTTPS,
                    DnsFeature.DNS_OVER_TLS,
                    DnsFeature.FAST_RESPONSE
                )
            ),
            
            // Quad9 DNS
            DnsServerInfo(
                id = "quad9_primary",
                serverAddress = "9.9.9.9",
                provider = DnsProvider.QUAD9,
                country = "Global",
                description = "Quad9 - Security focused with malware blocking",
                isSecure = true,
                supportsFiltering = true,
                averageResponseTime = 25,
                reliability = 99.7,
                privacyRating = 5,
                features = listOf(
                    DnsFeature.DNS_OVER_HTTPS,
                    DnsFeature.DNS_OVER_TLS,
                    DnsFeature.MALWARE_PROTECTION,
                    DnsFeature.PHISHING_PROTECTION,
                    DnsFeature.ZERO_LOGGING,
                    DnsFeature.ANYCAST
                )
            ),
            
            // OpenDNS
            DnsServerInfo(
                id = "opendns_primary",
                serverAddress = "208.67.222.222",
                provider = DnsProvider.OPENDNS,
                country = "United States",
                description = "OpenDNS - Content filtering and security",
                isSecure = true,
                supportsFiltering = true,
                averageResponseTime = 30,
                reliability = 99.5,
                privacyRating = 4,
                features = listOf(
                    DnsFeature.DNS_OVER_HTTPS,
                    DnsFeature.MALWARE_PROTECTION,
                    DnsFeature.PHISHING_PROTECTION,
                    DnsFeature.FAMILY_FILTER,
                    DnsFeature.AD_BLOCKING
                )
            ),
            
            // AdGuard DNS
            DnsServerInfo(
                id = "adguard_primary",
                serverAddress = "94.140.14.14",
                provider = DnsProvider.ADGUARD,
                country = "Global",
                description = "AdGuard DNS - Ad and tracker blocking",
                isSecure = true,
                supportsFiltering = true,
                averageResponseTime = 28,
                reliability = 99.6,
                privacyRating = 5,
                features = listOf(
                    DnsFeature.DNS_OVER_HTTPS,
                    DnsFeature.DNS_OVER_TLS,
                    DnsFeature.AD_BLOCKING,
                    DnsFeature.MALWARE_PROTECTION,
                    DnsFeature.ZERO_LOGGING
                )
            ),
            
            // NextDNS (Popular privacy-focused DNS)
            DnsServerInfo(
                id = "nextdns_primary",
                serverAddress = "45.90.28.0",
                provider = DnsProvider.CUSTOM,
                country = "Global",
                description = "NextDNS - Customizable privacy and security",
                isSecure = true,
                supportsFiltering = true,
                averageResponseTime = 18,
                reliability = 99.8,
                privacyRating = 5,
                features = listOf(
                    DnsFeature.DNS_OVER_HTTPS,
                    DnsFeature.DNS_OVER_TLS,
                    DnsFeature.AD_BLOCKING,
                    DnsFeature.MALWARE_PROTECTION,
                    DnsFeature.FAMILY_FILTER,
                    DnsFeature.ZERO_LOGGING,
                    DnsFeature.GEOGRAPHIC_BLOCKING
                )
            ),
            
            // Clean Browsing
            DnsServerInfo(
                id = "cleanbrowsing_family",
                serverAddress = "185.228.168.168",
                provider = DnsProvider.CLEAN_BROWSING,
                country = "Global",
                description = "CleanBrowsing - Family safe filtering",
                isSecure = true,
                supportsFiltering = true,
                averageResponseTime = 35,
                reliability = 99.4,
                privacyRating = 4,
                features = listOf(
                    DnsFeature.DNS_OVER_HTTPS,
                    DnsFeature.FAMILY_FILTER,
                    DnsFeature.MALWARE_PROTECTION,
                    DnsFeature.AD_BLOCKING
                )
            )
        )
    }
    
    fun detectCurrentDnsServers() {
        scope.launch {
            try {
                val currentServers = getCurrentDnsServers()
                _currentDnsServers.value = currentServers
                
                // Test current DNS performance
                if (currentServers.isNotEmpty()) {
                    testCurrentDnsPerformance(currentServers.first())
                }
            } catch (e: Exception) {
                _currentDnsServers.value = emptyList()
            }
        }
    }
    
    private fun getCurrentDnsServers(): List<String> {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val activeNetwork = connectivityManager.activeNetwork
                val linkProperties = connectivityManager.getLinkProperties(activeNetwork)
                linkProperties?.dnsServers?.map { it.hostAddress }?.filterNotNull() ?: emptyList()
            } else {
                // Fallback for older Android versions
                listOf("8.8.8.8", "8.8.4.4") // Default assumption
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    fun startAutomaticDnsOptimization() {
        scope.launch {
            _dnsOptimizationStatus.value = DnsOptimizationStatus(
                status = OptimizationStatus.TESTING,
                currentLatency = 0,
                potentialImprovement = 0,
                recommendation = "Testing DNS servers for optimal performance..."
            )
            
            val publicServers = getPublicDnsServers()
            val testResults = mutableListOf<DnsTestResult>()
            
            _dnsTestProgress.value = DnsTestProgress(
                currentServer = "",
                serverIndex = 0,
                totalServers = publicServers.size,
                currentQuery = "google.com",
                phase = DnsTestPhase.INITIALIZING,
                progress = 0.0f
            )
            
            // Test each DNS server
            publicServers.forEachIndexed { index, server ->
                _dnsTestProgress.value = DnsTestProgress(
                    currentServer = server.serverAddress,
                    serverIndex = index,
                    totalServers = publicServers.size,
                    currentQuery = "google.com",
                    phase = DnsTestPhase.TESTING_SPEED,
                    progress = (index.toFloat() / publicServers.size) * 0.8f
                )
                
                val result = testDnsServer(server)
                testResults.add(result)
                
                delay(500) // Brief pause between tests
            }
            
            _dnsTestProgress.value = DnsTestProgress(
                currentServer = "Analyzing results",
                serverIndex = publicServers.size,
                totalServers = publicServers.size,
                currentQuery = "",
                phase = DnsTestPhase.ANALYZING_RESULTS,
                progress = 0.9f
            )
            
            // Analyze results and find best DNS
            val bestDns = findBestDnsServer(testResults)
            _recommendedDns.value = publicServers.find { it.serverAddress == bestDns.dnsServer }
            _dnsTestResults.value = testResults.sortedBy { it.responseTimeMs }
            
            // Update optimization status
            val currentLatency = _currentDnsServers.value.firstOrNull()?.let { currentDns ->
                testResults.find { it.dnsServer == currentDns }?.responseTimeMs ?: 100
            } ?: 100
            
            val bestLatency = bestDns.responseTimeMs
            val improvement = currentLatency - bestLatency
            
            _dnsOptimizationStatus.value = DnsOptimizationStatus(
                status = if (improvement > 10) OptimizationStatus.NEEDS_FIXING else OptimizationStatus.OPTIMIZED,
                currentLatency = currentLatency,
                potentialImprovement = maxOf(0, improvement),
                recommendation = generateOptimizationRecommendation(improvement, bestDns)
            )
            
            _dnsTestProgress.value = DnsTestProgress(
                currentServer = "Complete",
                serverIndex = publicServers.size,
                totalServers = publicServers.size,
                currentQuery = "",
                phase = DnsTestPhase.COMPLETED,
                progress = 1.0f
            )
            
            delay(1000)
            _dnsTestProgress.value = null
        }
    }
    
    private suspend fun testDnsServer(server: DnsServerInfo): DnsTestResult {
        return withContext(Dispatchers.IO) {
            val testDomains = listOf("google.com", "github.com", "stackoverflow.com")
            val results = mutableListOf<Long>()
            
            testDomains.forEach { domain ->
                val startTime = System.nanoTime()
                try {
                    val addresses = InetAddress.getAllByName(domain)
                    if (addresses.isNotEmpty()) {
                        val endTime = System.nanoTime()
                        val responseTime = (endTime - startTime) / 1_000_000 // Convert to ms
                        results.add(responseTime)
                    }
                } catch (e: Exception) {
                    results.add(5000) // Timeout/error penalty
                }
            }
            
            val averageResponseTime = if (results.isNotEmpty()) results.average().toLong() else 5000L
            
            DnsTestResult(
                testTimestamp = System.currentTimeMillis(),
                dnsServer = server.serverAddress,
                dnsProvider = server.provider,
                queryDomain = "google.com",
                responseTimeMs = averageResponseTime,
                isSuccessful = averageResponseTime < 5000,
                resolvedIp = "8.8.8.8", // Simplified
                queryType = DnsQueryType.A_RECORD,
                location = server.country
            )
        }
    }
    
    private suspend fun testCurrentDnsPerformance(currentDns: String) {
        val result = testDnsServer(
            DnsServerInfo(
                id = "current",
                serverAddress = currentDns,
                provider = DnsProvider.ISP_DEFAULT,
                country = "Unknown",
                description = "Current DNS",
                isSecure = false,
                supportsFiltering = false,
                averageResponseTime = 0,
                reliability = 0.0,
                privacyRating = 0,
                features = emptyList()
            )
        )
        
        // Store current performance for comparison
    }
    
    private fun findBestDnsServer(results: List<DnsTestResult>): DnsTestResult {
        return results
            .filter { it.isSuccessful }
            .minByOrNull { it.responseTimeMs } 
            ?: results.first()
    }
    
    private fun generateOptimizationRecommendation(improvement: Long, bestDns: DnsTestResult): String {
        return when {
            improvement > 50 -> "🚀 Switch to ${bestDns.dnsServer} for ${improvement}ms faster DNS resolution!"
            improvement > 20 -> "⚡ Consider switching to ${bestDns.dnsServer} for ${improvement}ms improvement"
            improvement > 5 -> "✨ Minor improvement available: ${bestDns.dnsServer} (${improvement}ms faster)"
            else -> "✅ Your current DNS is already optimized!"
        }
    }
    
    fun switchToDnsServer(dnsServer: DnsServerInfo) {
        scope.launch {
            try {
                // Note: Actual DNS switching requires system-level access or VPN
                // This is a simulation for educational purposes
                
                _dnsOptimizationStatus.value = DnsOptimizationStatus(
                    status = OptimizationStatus.TESTING,
                    currentLatency = 0,
                    potentialImprovement = 0,
                    recommendation = "Switching to ${dnsServer.serverAddress}..."
                )
                
                delay(2000) // Simulate switching time
                
                // Simulate successful switch
                _currentDnsServers.value = listOf(dnsServer.serverAddress)
                
                _dnsOptimizationStatus.value = DnsOptimizationStatus(
                    status = OptimizationStatus.OPTIMIZED,
                    currentLatency = dnsServer.averageResponseTime,
                    potentialImprovement = 0,
                    recommendation = "✅ Successfully switched to ${dnsServer.description}"
                )
                
                // Test new DNS performance
                val newResult = testDnsServer(dnsServer)
                offlineDataRepository.insertDnsTestResult(newResult)
                
            } catch (e: Exception) {
                _dnsOptimizationStatus.value = DnsOptimizationStatus(
                    status = OptimizationStatus.NEEDS_FIXING,
                    currentLatency = 0,
                    potentialImprovement = 0,
                    recommendation = "❌ Failed to switch DNS: ${e.message}"
                )
            }
        }
    }
    
    private fun startPeriodicDnsMonitoring() {
        scope.launch {
            while (true) {
                delay(300_000) // Check every 5 minutes
                
                val currentServers = getCurrentDnsServers()
                if (currentServers != _currentDnsServers.value) {
                    _currentDnsServers.value = currentServers
                    
                    // Re-test performance if DNS changed
                    if (currentServers.isNotEmpty()) {
                        testCurrentDnsPerformance(currentServers.first())
                    }
                }
            }
        }
    }
    
    fun getDnsSecurityAnalysis(dnsServer: String): DnsSecurityAnalysis {
        val serverInfo = getPublicDnsServers().find { it.serverAddress == dnsServer }
        
        return DnsSecurityAnalysis(
            supportsDnssec = serverInfo?.features?.contains(DnsFeature.DNS_OVER_HTTPS) ?: false,
            blocksAds = serverInfo?.features?.contains(DnsFeature.AD_BLOCKING) ?: false,
            blocksMalware = serverInfo?.features?.contains(DnsFeature.MALWARE_PROTECTION) ?: false,
            blocksPhishing = serverInfo?.features?.contains(DnsFeature.PHISHING_PROTECTION) ?: false,
            logsPolicies = when (serverInfo?.privacyRating) {
                5 -> DnsLoggingPolicy.NO_LOGS
                4 -> DnsLoggingPolicy.MINIMAL_LOGS
                3 -> DnsLoggingPolicy.STANDARD_LOGS
                else -> DnsLoggingPolicy.UNKNOWN
            },
            supportsDoH = serverInfo?.features?.contains(DnsFeature.DNS_OVER_HTTPS) ?: false,
            supportsDoT = serverInfo?.features?.contains(DnsFeature.DNS_OVER_TLS) ?: false,
            securityScore = calculateSecurityScore(serverInfo)
        )
    }
    
    private fun calculateSecurityScore(serverInfo: DnsServerInfo?): Int {
        if (serverInfo == null) return 30
        
        var score = 50 // Base score
        
        if (serverInfo.features.contains(DnsFeature.DNS_OVER_HTTPS)) score += 15
        if (serverInfo.features.contains(DnsFeature.DNS_OVER_TLS)) score += 10
        if (serverInfo.features.contains(DnsFeature.MALWARE_PROTECTION)) score += 10
        if (serverInfo.features.contains(DnsFeature.ZERO_LOGGING)) score += 10
        if (serverInfo.privacyRating >= 4) score += 5
        
        return minOf(100, score)
    }
    
    fun getBenchmarkResults(): DnsBenchmarkResult? {
        val results = _dnsTestResults.value
        if (results.isEmpty()) return null
        
        val publicServers = getPublicDnsServers()
        val fastest = results.minByOrNull { it.responseTimeMs }
        val slowest = results.maxByOrNull { it.responseTimeMs }
        
        val fastestServer = fastest?.let { result ->
            publicServers.find { it.serverAddress == result.dnsServer }
        }
        val slowestServer = slowest?.let { result ->
            publicServers.find { it.serverAddress == result.dnsServer }
        }
        
        if (fastestServer == null || slowestServer == null) return null
        
        val reliabilityRanking = results.map { result ->
            val server = publicServers.find { it.serverAddress == result.dnsServer }
            server to (server?.reliability ?: 0.0)
        }.filterNotNull().sortedByDescending { it.second }
        
        val securityRanking = publicServers.map { server ->
            server to calculateSecurityScore(server)
        }.sortedByDescending { it.second }
        
        return DnsBenchmarkResult(
            fastestServer = fastestServer,
            slowestServer = slowestServer,
            averageResponseTime = results.map { it.responseTimeMs }.average().toLong(),
            reliabilityRanking = reliabilityRanking,
            securityRanking = securityRanking,
            recommendedServer = _recommendedDns.value ?: fastestServer
        )
    }
    
    fun clearDnsResults() {
        _dnsTestResults.value = emptyList()
        _recommendedDns.value = null
        _dnsTestProgress.value = null
    }
}