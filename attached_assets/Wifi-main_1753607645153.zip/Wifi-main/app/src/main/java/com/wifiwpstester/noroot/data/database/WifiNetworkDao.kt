package com.wifiwpstester.noroot.data.database

import androidx.room.*
import com.wifiwpstester.noroot.data.model.WifiNetwork
import com.wifiwpstester.noroot.data.model.SecurityType
import kotlinx.coroutines.flow.Flow

@Dao
interface WifiNetworkDao {
    
    @Query("SELECT * FROM wifi_networks ORDER BY lastSeen DESC")
    fun getAllNetworks(): Flow<List<WifiNetwork>>
    
    @Query("SELECT * FROM wifi_networks WHERE isWpsEnabled = 1 ORDER BY rssi DESC")
    fun getWpsEnabledNetworks(): Flow<List<WifiNetwork>>
    
    @Query("SELECT * FROM wifi_networks WHERE bssid = :bssid")
    suspend fun getNetworkByBssid(bssid: String): WifiNetwork?
    
    @Query("SELECT * FROM wifi_networks WHERE ssid LIKE '%' || :query || '%' OR bssid LIKE '%' || :query || '%'")
    fun searchNetworks(query: String): Flow<List<WifiNetwork>>
    
    @Query("SELECT * FROM wifi_networks WHERE securityType = :securityType")
    fun getNetworksBySecurityType(securityType: SecurityType): Flow<List<WifiNetwork>>
    
    @Query("SELECT * FROM wifi_networks WHERE rssi >= :minRssi ORDER BY rssi DESC")
    fun getNetworksBySignalStrength(minRssi: Int): Flow<List<WifiNetwork>>
    
    @Query("SELECT COUNT(*) FROM wifi_networks WHERE isWpsEnabled = 1")
    suspend fun getWpsEnabledCount(): Int
    
    @Query("SELECT COUNT(*) FROM wifi_networks")
    suspend fun getTotalNetworkCount(): Int
    
    @Query("SELECT * FROM wifi_networks WHERE lastSeen >= :timestamp ORDER BY lastSeen DESC")
    fun getRecentNetworks(timestamp: Long): Flow<List<WifiNetwork>>
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNetwork(network: WifiNetwork)
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNetworks(networks: List<WifiNetwork>)
    
    @Update
    suspend fun updateNetwork(network: WifiNetwork)
    
    @Delete
    suspend fun deleteNetwork(network: WifiNetwork)
    
    @Query("DELETE FROM wifi_networks WHERE lastSeen < :timestamp")
    suspend fun deleteOldNetworks(timestamp: Long)
    
    @Query("DELETE FROM wifi_networks")
    suspend fun deleteAllNetworks()
    
    @Query("SELECT DISTINCT manufacturerOui FROM wifi_networks WHERE manufacturerOui IS NOT NULL")
    suspend fun getAllManufacturers(): List<String>
    
    @Query("SELECT * FROM wifi_networks WHERE manufacturerOui = :oui ORDER BY rssi DESC")
    fun getNetworksByManufacturer(oui: String): Flow<List<WifiNetwork>>
}