package com.wifiwpstester.noroot.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// DNS Security Analysis
data class DnsSecurityAnalysis(
    val supportsDnssec: Boolean,
    val blocksAds: Boolean,
    val blocksMalware: Boolean,
    val blocksPhishing: Boolean,
    val logsPolicies: DnsLoggingPolicy,
    val supportsDoH: Boolean, // DNS over HTTPS
    val supportsDoT: Boolean, // DNS over TLS
    val securityScore: Int // 0-100
)

// DNS Benchmark Results
data class DnsBenchmarkResult(
    val fastestServer: DnsServerInfo,
    val slowestServer: DnsServerInfo,
    val averageResponseTime: Long,
    val reliabilityRanking: List<Pair<DnsServerInfo?, Double>>,
    val securityRanking: List<Pair<DnsServerInfo, Int>>,
    val recommendedServer: DnsServerInfo
)

// Network Analysis Models
@Entity(tableName = "network_analysis_sessions")
data class NetworkAnalysisSession(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val duration: Long,
    val networkType: NetworkType,
    val signalStrength: Int,
    val frequency: Int,
    val channel: Int,
    val bandwidth: Int,
    val congestionLevel: CongestionLevel,
    val recommendedActions: List<String>,
    val optimizationScore: Int
)

enum class CongestionLevel {
    LOW, MEDIUM, HIGH, SEVERE
}

// WiFi Channel Analysis
data class WifiChannelAnalysis(
    val channel: Int,
    val frequency: Int,
    val congestionLevel: CongestionLevel,
    val interferingNetworks: Int,
    val signalStrength: Int,
    val recommendedForUse: Boolean,
    val band: WifiBand
)

enum class WifiBand {
    BAND_2_4_GHZ,
    BAND_5_GHZ,
    BAND_6_GHZ
}

// Multi-Connection Status
data class MultiConnectionStatus(
    val isWifiConnected: Boolean,
    val isMobileConnected: Boolean,
    val wifiSpeed: Double,
    val mobileSpeed: Double,
    val combinedSpeed: Double,
    val recommendMultiPath: Boolean,
    val primaryConnection: ConnectionType
)

enum class ConnectionType {
    WIFI_ONLY,
    MOBILE_ONLY,
    WIFI_PRIMARY,
    MOBILE_PRIMARY,
    BALANCED
}

// Background Data Control
@Entity(tableName = "app_data_usage")
data class AppDataUsage(
    @PrimaryKey val packageName: String,
    val appName: String,
    val dataUsageMB: Double,
    val lastHourUsage: Double,
    val isDataHog: Boolean,
    val isBlocked: Boolean,
    val priority: AppPriority,
    val lastUpdated: Long
)

enum class AppPriority {
    CRITICAL,    // System apps, calls, messages
    HIGH,        // Work apps, navigation
    MEDIUM,      // Social media, news
    LOW,         // Games, entertainment
    BACKGROUND   // Updates, sync
}

// Smart VPN Acceleration
data class VpnAccelerationStatus(
    val isVpnActive: Boolean,
    val vpnProvider: String?,
    val accelerationAvailable: Boolean,
    val currentLatency: Int,
    val acceleratedLatency: Int,
    val speedImprovement: Double,
    val recommendedService: String?
)

// Network Optimization Recommendations
data class NetworkOptimizationRecommendation(
    val id: String,
    val type: OptimizationType,
    val title: String,
    val description: String,
    val impact: ImpactLevel,
    val difficulty: DifficultyLevel,
    val estimatedTime: Int, // minutes
    val steps: List<String>,
    val priority: Int
)

enum class OptimizationType {
    DNS_SWITCH,
    CHANNEL_CHANGE,
    POSITION_ADJUSTMENT,
    TIME_SCHEDULING,
    APP_MANAGEMENT,
    VPN_CONFIGURATION,
    MULTI_CONNECTION_SETUP,
    HARDWARE_UPGRADE
}

enum class ImpactLevel {
    HIGH,      // >30% improvement
    MEDIUM,    // 10-30% improvement
    LOW        // 5-10% improvement
}

enum class DifficultyLevel {
    EASY,      // One tap/automatic
    MODERATE,  // Few steps, no technical knowledge
    ADVANCED   // Technical configuration required
}

// Network Health Status
data class NetworkHealthStatus(
    val overallScore: Int, // 0-100
    val healthLevel: HealthLevel,
    val issues: List<NetworkIssue>,
    val strengths: List<String>,
    val lastAnalysis: Long,
    val trendDirection: TrendDirection
)

enum class HealthLevel {
    EXCELLENT,  // 90-100
    GOOD,       // 70-89
    FAIR,       // 50-69
    POOR,       // 30-49
    CRITICAL    // 0-29
}

data class NetworkIssue(
    val type: IssueType,
    val severity: IssueSeverity,
    val description: String,
    val solution: String,
    val canAutoFix: Boolean
)

enum class IssueType {
    SLOW_DNS,
    WEAK_SIGNAL,
    CHANNEL_CONGESTION,
    PEAK_HOUR_SLOWDOWN,
    DATA_HOG_APPS,
    SUBOPTIMAL_ROUTING,
    HARDWARE_LIMITATION
}

enum class IssueSeverity {
    CRITICAL,
    HIGH,
    MEDIUM,
    LOW,
    INFO
}

enum class TrendDirection {
    IMPROVING,
    STABLE,
    DECLINING
}

// Speed Test History
@Entity(tableName = "speed_test_history")
data class SpeedTestHistoryEntry(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val downloadSpeed: Double,
    val uploadSpeed: Double,
    val ping: Long,
    val jitter: Long,
    val networkType: NetworkType,
    val signalStrength: Int,
    val location: String?,
    val serverUsed: String,
    val testDuration: Long
)

// AI Prediction Models
data class NetworkPrediction(
    val timestamp: Long,
    val predictedSpeed: Double,
    val confidence: Double,
    val factors: List<PredictionFactor>
)

data class PredictionFactor(
    val name: String,
    val impact: Double, // -1.0 to 1.0
    val description: String
)

// Performance Metrics
data class NetworkPerformanceMetrics(
    val averageSpeed: Double,
    val peakSpeed: Double,
    val lowestSpeed: Double,
    val consistency: Double, // 0-1, higher is more consistent
    val reliability: Double, // 0-1, uptime percentage
    val latencyVariation: Double,
    val timeToFirstByte: Long
)

// Location-based Analysis
@Entity(tableName = "location_network_data")
data class LocationNetworkData(
    @PrimaryKey val id: String,
    val latitude: Double?,
    val longitude: Double?,
    val locationName: String,
    val averageSignalStrength: Int,
    val averageSpeed: Double,
    val bestChannel: Int,
    val optimalPosition: String?,
    val lastUpdated: Long
)