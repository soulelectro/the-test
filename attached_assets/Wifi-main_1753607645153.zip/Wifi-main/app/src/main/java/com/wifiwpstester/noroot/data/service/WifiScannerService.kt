package com.wifiwpstester.noroot.data.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import androidx.annotation.RequiresApi
import com.wifiwpstester.noroot.data.model.*
import com.wifiwpstester.noroot.data.repository.OfflineDataRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WifiScannerService @Inject constructor(
    private val context: Context,
    private val offlineDataRepository: OfflineDataRepository
) {
    
    private val wifiManager = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
    
    private val _scanResults = MutableStateFlow<NetworkScanResult?>(null)
    val scanResults: StateFlow<NetworkScanResult?> = _scanResults.asStateFlow()
    
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()
    
    private val _scanError = MutableStateFlow<String?>(null)
    val scanError: StateFlow<String?> = _scanError.asStateFlow()
    
    private val scanReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == WifiManager.SCAN_RESULTS_AVAILABLE_ACTION) {
                val success = intent.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false)
                if (success) {
                    processScanResults()
                } else {
                    _scanError.value = "Scan failed - please try again"
                    _isScanning.value = false
                }
            }
        }
    }
    
    fun startScan(): Boolean {
        if (!wifiManager.isWifiEnabled) {
            _scanError.value = "WiFi is disabled. Please enable WiFi to scan."
            return false
        }
        
        _isScanning.value = true
        _scanError.value = null
        
        // Register receiver for scan results
        val intentFilter = IntentFilter()
        intentFilter.addAction(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        context.registerReceiver(scanReceiver, intentFilter)
        
        // Start scan
        val scanStarted = wifiManager.startScan()
        if (!scanStarted) {
            _scanError.value = "Failed to start WiFi scan"
            _isScanning.value = false
            try {
                context.unregisterReceiver(scanReceiver)
            } catch (e: Exception) {
                // Receiver not registered
            }
            return false
        }
        
        return true
    }
    
    private fun processScanResults() {
        try {
            val scanResults = wifiManager.scanResults ?: emptyList()
            val networks = scanResults.map { scanResult ->
                convertScanResultToWifiNetwork(scanResult)
            }
            
            val wpsEnabledCount = networks.count { it.isWpsEnabled }
            val vulnerableCount = networks.count { 
                it.isWpsEnabled && isNetworkVulnerable(it)
            }
            
            val networkScanResult = NetworkScanResult(
                networks = networks,
                scanTime = System.currentTimeMillis(),
                totalNetworks = networks.size,
                wpsEnabledCount = wpsEnabledCount,
                vulnerableCount = vulnerableCount
            )
            
            _scanResults.value = networkScanResult
            _isScanning.value = false
            
            // Store results offline
            storeNetworksOffline(networks)
            
        } catch (e: Exception) {
            _scanError.value = "Error processing scan results: ${e.message}"
            _isScanning.value = false
        } finally {
            try {
                context.unregisterReceiver(scanReceiver)
            } catch (e: Exception) {
                // Receiver not registered
            }
        }
    }
    
    private fun convertScanResultToWifiNetwork(scanResult: ScanResult): WifiNetwork {
        val securityType = determineSecurityType(scanResult.capabilities)
        val isWpsEnabled = scanResult.capabilities.contains("WPS")
        val manufacturerOui = extractManufacturerOui(scanResult.BSSID)
        
        return WifiNetwork(
            bssid = scanResult.BSSID,
            ssid = scanResult.SSID ?: "Hidden Network",
            rssi = scanResult.level,
            frequency = scanResult.frequency,
            capabilities = scanResult.capabilities,
            isWpsEnabled = isWpsEnabled,
            securityType = securityType,
            manufacturerOui = manufacturerOui,
            lastSeen = System.currentTimeMillis(),
            channel = frequencyToChannel(scanResult.frequency),
            centerFreq0 = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) scanResult.centerFreq0 else 0,
            centerFreq1 = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) scanResult.centerFreq1 else 0,
            channelWidth = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) scanResult.channelWidth else 0
        )
    }
    
    private fun determineSecurityType(capabilities: String): SecurityType {
        return when {
            capabilities.contains("WPA3") -> SecurityType.WPA3
            capabilities.contains("WPA2") && capabilities.contains("WPA") -> SecurityType.WPA_WPA2
            capabilities.contains("WPA2") -> SecurityType.WPA2
            capabilities.contains("WPA") -> SecurityType.WPA
            capabilities.contains("WEP") -> SecurityType.WEP
            capabilities.contains("[ESS]") -> SecurityType.OPEN
            else -> SecurityType.UNKNOWN
        }
    }
    
    private fun extractManufacturerOui(bssid: String): String? {
        return try {
            val macParts = bssid.split(":")
            if (macParts.size >= 3) {
                "${macParts[0]}:${macParts[1]}:${macParts[2]}".uppercase()
            } else null
        } catch (e: Exception) {
            null
        }
    }
    
    private fun frequencyToChannel(frequency: Int): Int {
        return when {
            frequency in 2412..2484 -> (frequency - 2412) / 5 + 1
            frequency in 5170..5825 -> (frequency - 5000) / 5
            else -> 0
        }
    }
    
    private fun isNetworkVulnerable(network: WifiNetwork): Boolean {
        if (!network.isWpsEnabled) return false
        
        // Check for known vulnerable manufacturers
        val vulnerableOuis = offlineDataRepository.getVulnerableManufacturerOuis()
        network.manufacturerOui?.let { oui ->
            if (vulnerableOuis.contains(oui)) return true
        }
        
        // Check for weak security
        return when (network.securityType) {
            SecurityType.OPEN, SecurityType.WEP -> true
            SecurityType.WPA -> true // WPA is considered vulnerable
            else -> false
        }
    }
    
    private suspend fun storeNetworksOffline(networks: List<WifiNetwork>) {
        try {
            offlineDataRepository.insertNetworks(networks)
        } catch (e: Exception) {
            // Log error but don't fail the scan
        }
    }
    
    fun getLastScanResults(): NetworkScanResult? = _scanResults.value
    
    fun clearError() {
        _scanError.value = null
    }
}