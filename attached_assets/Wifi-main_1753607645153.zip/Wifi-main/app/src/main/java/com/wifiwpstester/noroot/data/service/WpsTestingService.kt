package com.wifiwpstester.noroot.data.service

import android.content.Context
import android.net.wifi.WifiConfiguration
import android.net.wifi.WifiManager
import android.net.wifi.WpsInfo
import android.os.Build
import androidx.annotation.RequiresApi
import com.wifiwpstester.noroot.data.model.*
import com.wifiwpstester.noroot.data.repository.OfflineDataRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WpsTestingService @Inject constructor(
    private val context: Context,
    private val offlineDataRepository: OfflineDataRepository
) {
    
    private val wifiManager = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    private val _testProgress = MutableStateFlow<WpsTestProgress?>(null)
    val testProgress: StateFlow<WpsTestProgress?> = _testProgress.asStateFlow()
    
    private val _testResult = MutableStateFlow<WpsTestResult?>(null)
    val testResult: StateFlow<WpsTestResult?> = _testResult.asStateFlow()
    
    private var currentTestJob: Job? = null
    
    data class WpsTestProgress(
        val currentPin: String,
        val currentPinIndex: Int,
        val totalPins: Int,
        val timeElapsed: Long,
        val estimatedTimeRemaining: Long,
        val isWpsLocked: Boolean = false,
        val lockoutTimeRemaining: Long = 0
    )
    
    fun startWpsTest(
        network: WifiNetwork,
        testType: TestType,
        customPins: List<String> = emptyList(),
        delayBetweenAttempts: Long = 1000L
    ) {
        if (currentTestJob?.isActive == true) {
            return // Test already running
        }
        
        currentTestJob = scope.launch {
            try {
                val startTime = System.currentTimeMillis()
                val pins = getPinsForTest(network, testType, customPins)
                
                var isWpsLocked = false
                var lockoutStartTime = 0L
                val lockoutDuration = 60000L // 1 minute lockout
                val maxAttemptsBeforeLockout = 10
                var attemptCount = 0
                val attemptedPins = mutableListOf<String>()
                
                for ((index, pin) in pins.withIndex()) {
                    // Check if test was cancelled
                    if (!currentTestJob!!.isActive) {
                        break
                    }
                    
                    // Check WPS lockout
                    if (isWpsLocked) {
                        val lockoutRemaining = lockoutDuration - (System.currentTimeMillis() - lockoutStartTime)
                        if (lockoutRemaining > 0) {
                            _testProgress.value = WpsTestProgress(
                                currentPin = pin,
                                currentPinIndex = index,
                                totalPins = pins.size,
                                timeElapsed = System.currentTimeMillis() - startTime,
                                estimatedTimeRemaining = calculateEstimatedTime(index, pins.size, startTime),
                                isWpsLocked = true,
                                lockoutTimeRemaining = lockoutRemaining
                            )
                            delay(1000) // Update every second during lockout
                            continue
                        } else {
                            isWpsLocked = false
                            attemptCount = 0
                        }
                    }
                    
                    // Update progress
                    _testProgress.value = WpsTestProgress(
                        currentPin = pin,
                        currentPinIndex = index,
                        totalPins = pins.size,
                        timeElapsed = System.currentTimeMillis() - startTime,
                        estimatedTimeRemaining = calculateEstimatedTime(index, pins.size, startTime),
                        isWpsLocked = false
                    )
                    
                    // Attempt WPS connection
                    val result = attemptWpsConnection(network, pin)
                    attemptedPins.add(pin)
                    attemptCount++
                    
                    when (result) {
                        WpsConnectionResult.SUCCESS -> {
                            // Success! Save result and exit
                            val testResult = WpsTestResult(
                                networkBssid = network.bssid,
                                networkSsid = network.ssid,
                                testType = testType,
                                result = TestResult.SUCCESS,
                                pinsAttempted = attemptedPins,
                                successfulPin = pin,
                                timeStarted = startTime,
                                timeCompleted = System.currentTimeMillis(),
                                duration = System.currentTimeMillis() - startTime,
                                riskLevel = RiskLevel.HIGH,
                                notes = "WPS PIN successfully cracked using $pin"
                            )
                            
                            _testResult.value = testResult
                            offlineDataRepository.insertTestResult(testResult)
                            return@launch
                        }
                        
                        WpsConnectionResult.WPS_LOCKED -> {
                            isWpsLocked = true
                            lockoutStartTime = System.currentTimeMillis()
                        }
                        
                        WpsConnectionResult.FAILED -> {
                            // Continue to next PIN
                        }
                        
                        WpsConnectionResult.NETWORK_UNAVAILABLE -> {
                            // Network disappeared, end test
                            val testResult = WpsTestResult(
                                networkBssid = network.bssid,
                                networkSsid = network.ssid,
                                testType = testType,
                                result = TestResult.NETWORK_UNAVAILABLE,
                                pinsAttempted = attemptedPins,
                                successfulPin = null,
                                timeStarted = startTime,
                                timeCompleted = System.currentTimeMillis(),
                                duration = System.currentTimeMillis() - startTime,
                                riskLevel = RiskLevel.LOW,
                                notes = "Network became unavailable during test"
                            )
                            
                            _testResult.value = testResult
                            offlineDataRepository.insertTestResult(testResult)
                            return@launch
                        }
                    }
                    
                    // Check if we should trigger lockout simulation
                    if (attemptCount >= maxAttemptsBeforeLockout && !isWpsLocked) {
                        isWpsLocked = true
                        lockoutStartTime = System.currentTimeMillis()
                        attemptCount = 0
                    }
                    
                    // Delay between attempts
                    delay(delayBetweenAttempts)
                }
                
                // All PINs attempted without success
                val finalResult = if (isWpsLocked) TestResult.WPS_LOCKED else TestResult.FAILED
                val riskLevel = if (attemptedPins.size > 50) RiskLevel.LOW else RiskLevel.MEDIUM
                
                val testResult = WpsTestResult(
                    networkBssid = network.bssid,
                    networkSsid = network.ssid,
                    testType = testType,
                    result = finalResult,
                    pinsAttempted = attemptedPins,
                    successfulPin = null,
                    timeStarted = startTime,
                    timeCompleted = System.currentTimeMillis(),
                    duration = System.currentTimeMillis() - startTime,
                    riskLevel = riskLevel,
                    isWpsLocked = isWpsLocked,
                    lockoutDuration = if (isWpsLocked) lockoutDuration else 0,
                    attemptsBeforeLockout = maxAttemptsBeforeLockout,
                    notes = if (isWpsLocked) "WPS locked after $attemptCount attempts" else "All PINs attempted without success"
                )
                
                _testResult.value = testResult
                offlineDataRepository.insertTestResult(testResult)
                
            } catch (e: Exception) {
                // Handle error
                val testResult = WpsTestResult(
                    networkBssid = network.bssid,
                    networkSsid = network.ssid,
                    testType = testType,
                    result = TestResult.FAILED,
                    pinsAttempted = emptyList(),
                    successfulPin = null,
                    timeStarted = System.currentTimeMillis(),
                    timeCompleted = System.currentTimeMillis(),
                    duration = 0,
                    riskLevel = RiskLevel.LOW,
                    notes = "Test failed with error: ${e.message}"
                )
                
                _testResult.value = testResult
                offlineDataRepository.insertTestResult(testResult)
            }
        }
    }
    
    private fun getPinsForTest(
        network: WifiNetwork,
        testType: TestType,
        customPins: List<String>
    ): List<String> {
        return when (testType) {
            TestType.DEFAULT_PINS -> {
                val defaultPins = offlineDataRepository.getDefaultWpsPins()
                val manufacturerPins = network.manufacturerOui?.let { oui ->
                    val manufacturer = offlineDataRepository.getManufacturerOuis()[oui]
                    defaultPins.filter { it.manufacturer == manufacturer }
                } ?: emptyList()
                
                val genericPins = defaultPins.filter { it.manufacturer == null }
                (manufacturerPins + genericPins).sortedBy { it.priority }.map { it.pin }
            }
            
            TestType.MANUAL_PIN -> customPins
            
            TestType.DICTIONARY_ATTACK -> {
                generateDictionaryPins()
            }
            
            TestType.SEQUENTIAL_ATTACK -> {
                generateSequentialPins()
            }
            
            TestType.MANUFACTURER_SPECIFIC -> {
                network.manufacturerOui?.let { oui ->
                    val manufacturer = offlineDataRepository.getManufacturerOuis()[oui]
                    offlineDataRepository.getDefaultWpsPins()
                        .filter { it.manufacturer == manufacturer }
                        .sortedBy { it.priority }
                        .map { it.pin }
                } ?: emptyList()
            }
        }
    }
    
    private fun generateDictionaryPins(): List<String> {
        // Generate common PIN patterns offline
        val pins = mutableListOf<String>()
        
        // Common patterns
        pins.addAll(listOf(
            "12345670", "00000000", "11111111", "12345678", "87654321",
            "00000001", "11111110", "22222222", "33333333", "44444444",
            "55555555", "66666666", "77777777", "88888888", "99999999",
            "01234567", "76543210", "13579135", "24681357", "11223344"
        ))
        
        // Date-based PINs
        val currentYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
        for (year in (currentYear - 10)..currentYear) {
            pins.add("${year}0101")
            pins.add("01012000".take(4) + year.toString().takeLast(2) + "01")
        }
        
        // Sequential patterns
        for (i in 0..9) {
            pins.add(i.toString().repeat(8))
            pins.add("${i}${i}${i}${i}${i}${i}${i}0")
        }
        
        return pins.distinct()
    }
    
    private fun generateSequentialPins(): List<String> {
        val pins = mutableListOf<String>()
        
        // Generate all 8-digit combinations (limited for performance)
        // In a real implementation, this would be much more extensive
        for (i in 0..9999) {
            val pin = i.toString().padStart(8, '0')
            pins.add(pin)
            if (pins.size >= 10000) break // Limit to prevent excessive testing
        }
        
        return pins
    }
    
    private suspend fun attemptWpsConnection(network: WifiNetwork, pin: String): WpsConnectionResult {
        return withContext(Dispatchers.Main) {
            try {
                // Simulate WPS connection attempt
                // Note: Actual WPS connection requires system-level access
                // This is a simulation for educational purposes
                
                delay(100) // Simulate connection attempt time
                
                // Simulate different outcomes based on PIN patterns
                when {
                    pin == "12345670" && network.manufacturerOui?.startsWith("14:CC:20") == true -> {
                        // Simulate TP-Link default PIN success
                        WpsConnectionResult.SUCCESS
                    }
                    pin == "00000000" -> {
                        // Simulate common failure
                        WpsConnectionResult.FAILED
                    }
                    pin.all { it == pin[0] } -> {
                        // Simulate WPS lockout for repeated patterns
                        WpsConnectionResult.WPS_LOCKED
                    }
                    !wifiManager.isWifiEnabled -> {
                        WpsConnectionResult.NETWORK_UNAVAILABLE
                    }
                    else -> {
                        // Random outcome for demonstration
                        if (Math.random() < 0.01) { // 1% success rate for demo
                            WpsConnectionResult.SUCCESS
                        } else if (Math.random() < 0.05) { // 5% lockout rate for demo
                            WpsConnectionResult.WPS_LOCKED
                        } else {
                            WpsConnectionResult.FAILED
                        }
                    }
                }
            } catch (e: Exception) {
                WpsConnectionResult.FAILED
            }
        }
    }
    
    private fun calculateEstimatedTime(currentIndex: Int, totalPins: Int, startTime: Long): Long {
        if (currentIndex == 0) return 0
        
        val elapsedTime = System.currentTimeMillis() - startTime
        val averageTimePerPin = elapsedTime / currentIndex
        val remainingPins = totalPins - currentIndex
        
        return remainingPins * averageTimePerPin
    }
    
    fun cancelTest() {
        currentTestJob?.cancel()
        _testProgress.value = null
    }
    
    fun clearResults() {
        _testResult.value = null
        _testProgress.value = null
    }
    
    enum class WpsConnectionResult {
        SUCCESS,
        FAILED,
        WPS_LOCKED,
        NETWORK_UNAVAILABLE
    }
}