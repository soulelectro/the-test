package com.wifiwpstester.noroot.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wifiwpstester.noroot.ui.viewmodel.MainViewModel

@Composable
fun WpsTestScreen(
    bssid: String,
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit
) {
    val testProgress by viewModel.testProgress.collectAsState()
    val testResult by viewModel.testResult.collectAsState()
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "WPS Test",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Testing network: $bssid",
            style = MaterialTheme.typography.bodyLarge
        )
        
        testProgress?.let { progress ->
            Spacer(modifier = Modifier.height(16.dp))
            Text("Testing PIN: ${progress.currentPin}")
            Text("Progress: ${progress.currentPinIndex}/${progress.totalPins}")
            LinearProgressIndicator(
                progress = progress.currentPinIndex.toFloat() / progress.totalPins,
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
            )
        }
        
        testResult?.let { result ->
            Spacer(modifier = Modifier.height(16.dp))
            Text("Result: ${result.result}")
            Text("Duration: ${result.duration}ms")
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = onNavigateBack) {
            Text("Back")
        }
    }
}