package com.wifiwpstester.noroot.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "speed_test_results")
data class SpeedTestResult(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val testTimestamp: Long,
    val downloadSpeedMbps: Double,
    val uploadSpeedMbps: Double,
    val pingMs: Long,
    val jitterMs: Long,
    val packetLoss: Double,
    val testDurationMs: Long,
    val networkType: NetworkType,
    val serverLocation: String,
    val testServer: String,
    val connectionQuality: ConnectionQuality
)

@Entity(tableName = "server_status")
data class ServerStatus(
    @PrimaryKey
    val serverId: String,
    val serverName: String,
    val serverUrl: String,
    val country: String,
    val region: String,
    val isOnline: Boolean,
    val responseTimeMs: Long,
    val lastChecked: Long,
    val statusCode: Int,
    val errorMessage: String? = null,
    val serverType: ServerType
)

@Entity(tableName = "social_media_servers")
data class SocialMediaServer(
    @PrimaryKey
    val id: String,
    val platform: SocialMediaPlatform,
    val serverName: String,
    val serverUrl: String,
    val country: String,
    val region: String,
    val ipAddress: String,
    val port: Int = 443,
    val isMainServer: Boolean = false,
    val description: String
)

enum class NetworkType {
    WIFI,
    MOBILE_4G,
    MOBILE_5G,
    MOBILE_3G,
    ETHERNET,
    UNKNOWN
}

enum class ConnectionQuality {
    EXCELLENT,
    GOOD,
    FAIR,
    POOR,
    VERY_POOR
}

enum class ServerType {
    WEB_SERVER,
    API_SERVER,
    CDN,
    DNS_SERVER,
    SOCIAL_MEDIA,
    STREAMING,
    GAMING,
    CLOUD_SERVICE
}

enum class SocialMediaPlatform {
    FACEBOOK,
    INSTAGRAM,
    TWITTER,
    YOUTUBE,
    TIKTOK,
    LINKEDIN,
    SNAPCHAT,
    DISCORD,
    TELEGRAM,
    WHATSAPP,
    REDDIT,
    PINTEREST
}

data class SpeedTestProgress(
    val phase: TestPhase,
    val progress: Float,
    val currentSpeed: Double,
    val timeElapsed: Long,
    val estimatedTimeRemaining: Long
)

enum class TestPhase {
    INITIALIZING,
    PING_TEST,
    DOWNLOAD_TEST,
    UPLOAD_TEST,
    COMPLETING,
    FINISHED
}

data class ServerMonitoringResult(
    val totalServers: Int,
    val onlineServers: Int,
    val offlineServers: Int,
    val averageResponseTime: Long,
    val serversByCountry: Map<String, List<ServerStatus>>,
    val lastUpdated: Long
)

data class NetworkSpeedSummary(
    val averageDownload: Double,
    val averageUpload: Double,
    val averagePing: Long,
    val testCount: Int,
    val bestSpeed: SpeedTestResult?,
    val worstSpeed: SpeedTestResult?,
    val speedTrend: SpeedTrend
)

enum class SpeedTrend {
    IMPROVING,
    STABLE,
    DECLINING,
    INSUFFICIENT_DATA
}