package com.wifiwpstester.noroot.data.database

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import android.content.Context
import com.wifiwpstester.noroot.data.model.WifiNetwork
import com.wifiwpstester.noroot.data.model.WpsTestResult

@Database(
    entities = [WifiNetwork::class, WpsTestResult::class],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class WifiWpsDatabase : RoomDatabase() {
    
    abstract fun wifiNetworkDao(): WifiNetworkDao
    abstract fun wpsTestDao(): WpsTestDao
    
    companion object {
        @Volatile
        private var INSTANCE: WifiWpsDatabase? = null
        
        fun getDatabase(context: Context): WifiWpsDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WifiWpsDatabase::class.java,
                    "wifi_wps_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}