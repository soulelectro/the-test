package com.wifiwpstester.noroot.data.database

import androidx.room.*
import com.wifiwpstester.noroot.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WpsTestDao {
    
    @Query("SELECT * FROM wps_test_results ORDER BY timeStarted DESC")
    fun getAllTestResults(): Flow<List<WpsTestResult>>
    
    @Query("SELECT * FROM wps_test_results WHERE networkBssid = :bssid ORDER BY timeStarted DESC")
    fun getTestResultsForNetwork(bssid: String): Flow<List<WpsTestResult>>
    
    @Query("SELECT * FROM wps_test_results WHERE result = :result ORDER BY timeStarted DESC")
    fun getTestResultsByResult(result: TestResult): Flow<List<WpsTestResult>>
    
    @Query("SELECT * FROM wps_test_results WHERE testType = :testType ORDER BY timeStarted DESC")
    fun getTestResultsByType(testType: TestType): Flow<List<WpsTestResult>>
    
    @Query("SELECT * FROM wps_test_results WHERE riskLevel = :riskLevel ORDER BY timeStarted DESC")
    fun getTestResultsByRiskLevel(riskLevel: RiskLevel): Flow<List<WpsTestResult>>
    
    @Query("SELECT * FROM wps_test_results WHERE timeStarted >= :startTime AND timeStarted <= :endTime ORDER BY timeStarted DESC")
    fun getTestResultsByDateRange(startTime: Long, endTime: Long): Flow<List<WpsTestResult>>
    
    @Query("SELECT * FROM wps_test_results WHERE networkSsid LIKE '%' || :query || '%' OR networkBssid LIKE '%' || :query || '%' OR notes LIKE '%' || :query || '%'")
    fun searchTestResults(query: String): Flow<List<WpsTestResult>>
    
    @Query("SELECT COUNT(*) FROM wps_test_results")
    suspend fun getTotalTestCount(): Int
    
    @Query("SELECT COUNT(*) FROM wps_test_results WHERE result = :result")
    suspend fun getTestCountByResult(result: TestResult): Int
    
    @Query("SELECT AVG(duration) FROM wps_test_results WHERE result = 'SUCCESS'")
    suspend fun getAverageSuccessfulTestDuration(): Long?
    
    @Query("SELECT riskLevel, COUNT(*) as count FROM wps_test_results GROUP BY riskLevel")
    suspend fun getRiskLevelDistribution(): Map<RiskLevel, Int>
    
    @Query("SELECT * FROM wps_test_results WHERE id = :id")
    suspend fun getTestResultById(id: Long): WpsTestResult?
    
    @Insert
    suspend fun insertTestResult(testResult: WpsTestResult): Long
    
    @Insert
    suspend fun insertTestResults(testResults: List<WpsTestResult>)
    
    @Update
    suspend fun updateTestResult(testResult: WpsTestResult)
    
    @Delete
    suspend fun deleteTestResult(testResult: WpsTestResult)
    
    @Query("DELETE FROM wps_test_results WHERE timeStarted < :timestamp")
    suspend fun deleteOldTestResults(timestamp: Long)
    
    @Query("DELETE FROM wps_test_results")
    suspend fun deleteAllTestResults()
    
    @Query("SELECT * FROM wps_test_results WHERE result = 'SUCCESS' ORDER BY timeStarted DESC LIMIT :limit")
    suspend fun getRecentSuccessfulTests(limit: Int): List<WpsTestResult>
    
    @Query("SELECT networkBssid, COUNT(*) as testCount FROM wps_test_results GROUP BY networkBssid ORDER BY testCount DESC LIMIT :limit")
    suspend fun getMostTestedNetworks(limit: Int): List<NetworkTestCount>
}

data class NetworkTestCount(
    val networkBssid: String,
    val testCount: Int
)