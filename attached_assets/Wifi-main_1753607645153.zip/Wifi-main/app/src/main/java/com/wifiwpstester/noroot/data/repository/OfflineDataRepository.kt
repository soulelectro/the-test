package com.wifiwpstester.noroot.data.repository

import com.wifiwpstester.noroot.data.database.WifiNetworkDao
import com.wifiwpstester.noroot.data.database.WpsTestDao
import com.wifiwpstester.noroot.data.model.*
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OfflineDataRepository @Inject constructor(
    private val wifiNetworkDao: WifiNetworkDao,
    private val wpsTestDao: WpsTestDao
) {
    
    // Network operations
    fun getAllNetworks(): Flow<List<WifiNetwork>> = wifiNetworkDao.getAllNetworks()
    fun getWpsEnabledNetworks(): Flow<List<WifiNetwork>> = wifiNetworkDao.getWpsEnabledNetworks()
    suspend fun insertNetworks(networks: List<WifiNetwork>) = wifiNetworkDao.insertNetworks(networks)
    suspend fun getNetworkByBssid(bssid: String): WifiNetwork? = wifiNetworkDao.getNetworkByBssid(bssid)
    
    // Test results operations
    fun getAllTestResults(): Flow<List<WpsTestResult>> = wpsTestDao.getAllTestResults()
    suspend fun insertTestResult(testResult: WpsTestResult): Long = wpsTestDao.insertTestResult(testResult)
    fun getTestResultsForNetwork(bssid: String): Flow<List<WpsTestResult>> = wpsTestDao.getTestResultsForNetwork(bssid)
    
    // Speed test operations
    suspend fun insertSpeedTestResult(result: SpeedTestResult) {
        // Implementation would insert into speed test table
    }
    
    // DNS test operations  
    suspend fun insertDnsTestResult(result: DnsTestResult) {
        // Implementation would insert into DNS test table
    }
    
    // VPN analysis operations
    suspend fun insertVpnAnalysisResult(result: VpnAnalysisResult) {
        // Implementation would insert into VPN analysis table
    }
    
    // Offline manufacturer OUI database (stored locally, no internet required)
    fun getManufacturerOuis(): Map<String, String> = mapOf(
        "00:11:22" to "Cisco Systems",
        "00:14:22" to "Dell Inc.",
        "00:15:6D" to "Cisco Systems",
        "00:16:B6" to "Cisco Systems",
        "00:1B:0D" to "Cisco Systems",
        "00:1C:10" to "Cisco Systems",
        "00:21:1B" to "Dell Inc.",
        "00:23:04" to "Cisco Systems",
        "00:25:45" to "Cisco Systems",
        "00:26:0A" to "Cisco Systems",
        "00:50:56" to "VMware",
        "08:00:07" to "Apple Inc.",
        "08:00:20" to "Sun Microsystems",
        "08:00:2B" to "Digital Equipment Corporation",
        "10:00:5A" to "IBM Corp.",
        "18:03:73" to "Dell Inc.",
        "20:87:56" to "Hewlett Packard Enterprise",
        "24:BE:05" to "Hewlett Packard Enterprise",
        "28:92:4A" to "Hewlett Packard Enterprise",
        "3C:D9:2B" to "Hewlett Packard Enterprise",
        "48:DF:37" to "Cisco Systems",
        "50:E5:49" to "Cisco Systems",
        "54:75:D0" to "Cisco Systems",
        "58:8D:09" to "Cisco Systems",
        "5C:50:15" to "Cisco Systems",
        "68:EF:BD" to "Cisco Systems",
        "70:CA:9B" to "Cisco Systems",
        "74:A0:2F" to "Cisco Systems",
        "78:DA:6E" to "Cisco Systems",
        "84:78:AC" to "Cisco Systems",
        "88:43:E1" to "Cisco Systems",
        "8C:60:4F" to "Cisco Systems",
        "90:E6:BA" to "Cisco Systems",
        "A0:E0:AF" to "Cisco Systems",
        "A4:6C:2A" to "Cisco Systems",
        "A8:B1:D4" to "Cisco Systems",
        "B8:BE:BF" to "Cisco Systems",
        "C0:62:6B" to "Cisco Systems",
        "C4:64:13" to "Cisco Systems",
        "C8:4C:75" to "Cisco Systems",
        "CC:EF:48" to "Cisco Systems",
        "D0:57:4C" to "Cisco Systems",
        "D4:8C:B5" to "Cisco Systems",
        "E0:2F:6D" to "Cisco Systems",
        "E4:AA:5D" to "Cisco Systems",
        "E8:BA:70" to "Cisco Systems",
        "F0:25:72" to "Cisco Systems",
        "F4:CF:E2" to "Cisco Systems",
        "F8:C2:88" to "Cisco Systems",
        "FC:99:47" to "Cisco Systems",
        
        // TP-Link
        "14:CC:20" to "TP-Link Technologies",
        "18:D6:C7" to "TP-Link Technologies",
        "1C:61:B4" to "TP-Link Technologies",
        "20:F4:78" to "TP-Link Technologies",
        "24:A4:3C" to "TP-Link Technologies",
        "28:6C:07" to "TP-Link Technologies",
        "2C:30:33" to "TP-Link Technologies",
        "30:B5:C2" to "TP-Link Technologies",
        "34:08:04" to "TP-Link Technologies",
        "38:2C:4A" to "TP-Link Technologies",
        "3C:84:6A" to "TP-Link Technologies",
        "40:ED:00" to "TP-Link Technologies",
        "44:D9:E7" to "TP-Link Technologies",
        "48:3B:38" to "TP-Link Technologies",
        "4C:ED:FB" to "TP-Link Technologies",
        "50:C7:BF" to "TP-Link Technologies",
        "54:AF:97" to "TP-Link Technologies",
        "58:D9:C3" to "TP-Link Technologies",
        "5C:E9:31" to "TP-Link Technologies",
        "60:E3:27" to "TP-Link Technologies",
        "64:70:02" to "TP-Link Technologies",
        "68:FF:7B" to "TP-Link Technologies",
        "6C:5A:B0" to "TP-Link Technologies",
        "70:4F:57" to "TP-Link Technologies",
        "74:DA:38" to "TP-Link Technologies",
        "78:8A:20" to "TP-Link Technologies",
        "7C:8B:CA" to "TP-Link Technologies",
        "80:EA:96" to "TP-Link Technologies",
        "84:16:F9" to "TP-Link Technologies",
        "88:C3:97" to "TP-Link Technologies",
        "8C:A6:DF" to "TP-Link Technologies",
        "90:F6:52" to "TP-Link Technologies",
        "94:E9:79" to "TP-Link Technologies",
        "98:DA:C4" to "TP-Link Technologies",
        "9C:A6:15" to "TP-Link Technologies",
        "A0:F3:C1" to "TP-Link Technologies",
        "A4:2B:B0" to "TP-Link Technologies",
        "A8:57:4E" to "TP-Link Technologies",
        "AC:84:C6" to "TP-Link Technologies",
        "B0:4E:26" to "TP-Link Technologies",
        "B4:B0:24" to "TP-Link Technologies",
        "B8:69:F4" to "TP-Link Technologies",
        "BC:46:99" to "TP-Link Technologies",
        "C0:25:E9" to "TP-Link Technologies",
        "C4:E9:84" to "TP-Link Technologies",
        "C8:3A:35" to "TP-Link Technologies",
        "CC:32:E5" to "TP-Link Technologies",
        "D0:73:D5" to "TP-Link Technologies",
        "D4:6E:0E" to "TP-Link Technologies",
        "D8:0D:17" to "TP-Link Technologies",
        "DC:4A:3E" to "TP-Link Technologies",
        "E0:28:6D" to "TP-Link Technologies",
        "E4:C3:2A" to "TP-Link Technologies",
        "E8:DE:27" to "TP-Link Technologies",
        "EC:08:6B" to "TP-Link Technologies",
        "F0:2F:74" to "TP-Link Technologies",
        "F4:F2:6D" to "TP-Link Technologies",
        "F8:1A:67" to "TP-Link Technologies",
        "FC:EC:DA" to "TP-Link Technologies",
        
        // D-Link
        "00:05:5D" to "D-Link Corporation",
        "00:0D:88" to "D-Link Corporation",
        "00:11:95" to "D-Link Corporation",
        "00:13:46" to "D-Link Corporation",
        "00:15:E9" to "D-Link Corporation",
        "00:17:9A" to "D-Link Corporation",
        "00:19:5B" to "D-Link Corporation",
        "00:1B:11" to "D-Link Corporation",
        "00:1C:F0" to "D-Link Corporation",
        "00:1E:58" to "D-Link Corporation",
        "00:21:91" to "D-Link Corporation",
        "00:22:B0" to "D-Link Corporation",
        "00:24:01" to "D-Link Corporation",
        "00:26:5A" to "D-Link Corporation",
        "14:D6:4D" to "D-Link Corporation",
        "1C:7E:E5" to "D-Link Corporation",
        "20:CF:30" to "D-Link Corporation",
        "28:10:7B" to "D-Link Corporation",
        "2C:AB:A4" to "D-Link Corporation",
        "34:81:C4" to "D-Link Corporation",
        "40:61:86" to "D-Link Corporation",
        "50:46:5D" to "D-Link Corporation",
        "5C:D9:98" to "D-Link Corporation",
        "78:54:2E" to "D-Link Corporation",
        "84:C9:B2" to "D-Link Corporation",
        "90:94:E4" to "D-Link Corporation",
        "A0:AB:1B" to "D-Link Corporation",
        "B8:A3:86" to "D-Link Corporation",
        "C8:D3:A3" to "D-Link Corporation",
        "CC:B2:55" to "D-Link Corporation",
        "E4:6F:13" to "D-Link Corporation",
        "F0:7D:68" to "D-Link Corporation",
        
        // Netgear
        "00:09:5B" to "Netgear Inc.",
        "00:0F:B5" to "Netgear Inc.",
        "00:14:6C" to "Netgear Inc.",
        "00:18:4D" to "Netgear Inc.",
        "00:1B:2F" to "Netgear Inc.",
        "00:1E:2A" to "Netgear Inc.",
        "00:22:3F" to "Netgear Inc.",
        "00:24:B2" to "Netgear Inc.",
        "00:26:F2" to "Netgear Inc.",
        "20:4E:7F" to "Netgear Inc.",
        "28:C6:8E" to "Netgear Inc.",
        "30:46:9A" to "Netgear Inc.",
        "40:0D:10" to "Netgear Inc.",
        "44:94:FC" to "Netgear Inc.",
        "4C:60:DE" to "Netgear Inc.",
        "84:1B:5E" to "Netgear Inc.",
        "A0:21:B7" to "Netgear Inc.",
        "B0:7F:B9" to "Netgear Inc.",
        "C0:3F:0E" to "Netgear Inc.",
        "E0:46:9A" to "Netgear Inc.",
        
        // Linksys
        "00:06:25" to "Linksys LLC",
        "00:0C:41" to "Linksys LLC",
        "00:12:17" to "Linksys LLC",
        "00:13:10" to "Linksys LLC",
        "00:14:BF" to "Linksys LLC",
        "00:16:B6" to "Linksys LLC",
        "00:18:39" to "Linksys LLC",
        "00:18:F8" to "Linksys LLC",
        "00:1A:70" to "Linksys LLC",
        "00:1C:10" to "Linksys LLC",
        "00:1D:7E" to "Linksys LLC",
        "00:1E:E5" to "Linksys LLC",
        "00:20:A6" to "Linksys LLC",
        "00:21:29" to "Linksys LLC",
        "00:22:6B" to "Linksys LLC",
        "00:23:69" to "Linksys LLC",
        "00:25:9C" to "Linksys LLC",
        "10:BF:48" to "Linksys LLC",
        "14:91:82" to "Linksys LLC",
        "20:AA:4B" to "Linksys LLC",
        "24:F5:A2" to "Linksys LLC",
        "30:23:03" to "Linksys LLC",
        "48:F8:B3" to "Linksys LLC",
        "58:6D:8F" to "Linksys LLC",
        "60:38:E0" to "Linksys LLC",
        "98:01:A7" to "Linksys LLC",
        "C0:56:27" to "Linksys LLC",
        "C4:41:1E" to "Linksys LLC",
        "E4:F4:C6" to "Linksys LLC"
    )
    
    // Offline default WPS PINs database (no internet required)
    fun getDefaultWpsPins(): List<WpsPin> = listOf(
        // Generic default PINs
        WpsPin("12345670", "Common default PIN", null, true, 1),
        WpsPin("00000000", "All zeros PIN", null, true, 2),
        WpsPin("11111111", "All ones PIN", null, true, 3),
        WpsPin("12345678", "Sequential PIN", null, true, 4),
        WpsPin("87654321", "Reverse sequential PIN", null, true, 5),
        WpsPin("00000001", "Minimal PIN", null, true, 6),
        WpsPin("11111110", "Common variant", null, true, 7),
        WpsPin("22222222", "All twos PIN", null, true, 8),
        WpsPin("33333333", "All threes PIN", null, true, 9),
        WpsPin("44444444", "All fours PIN", null, true, 10),
        
        // TP-Link default PINs
        WpsPin("12345670", "TP-Link default", "TP-Link Technologies", true, 1),
        WpsPin("00000000", "TP-Link variant", "TP-Link Technologies", true, 2),
        WpsPin("28107838", "TP-Link specific", "TP-Link Technologies", true, 3),
        WpsPin("94329434", "TP-Link model specific", "TP-Link Technologies", true, 4),
        WpsPin("12345678", "TP-Link common", "TP-Link Technologies", true, 5),
        
        // D-Link default PINs
        WpsPin("68425587", "D-Link default", "D-Link Corporation", true, 1),
        WpsPin("76229909", "D-Link variant", "D-Link Corporation", true, 2),
        WpsPin("20329909", "D-Link specific", "D-Link Corporation", true, 3),
        WpsPin("12345670", "D-Link common", "D-Link Corporation", true, 4),
        WpsPin("00000000", "D-Link fallback", "D-Link Corporation", true, 5),
        
        // Netgear default PINs
        WpsPin("22550550", "Netgear default", "Netgear Inc.", true, 1),
        WpsPin("76229909", "Netgear variant", "Netgear Inc.", true, 2),
        WpsPin("12345670", "Netgear common", "Netgear Inc.", true, 3),
        WpsPin("11111111", "Netgear simple", "Netgear Inc.", true, 4),
        WpsPin("password", "Netgear text PIN", "Netgear Inc.", true, 5),
        
        // Linksys default PINs
        WpsPin("20329909", "Linksys default", "Linksys LLC", true, 1),
        WpsPin("12345670", "Linksys common", "Linksys LLC", true, 2),
        WpsPin("admin123", "Linksys admin PIN", "Linksys LLC", true, 3),
        WpsPin("00000000", "Linksys fallback", "Linksys LLC", true, 4),
        
        // Asus default PINs
        WpsPin("12345670", "Asus default", "ASUSTeK Computer", true, 1),
        WpsPin("00000000", "Asus variant", "ASUSTeK Computer", true, 2),
        WpsPin("admin123", "Asus admin", "ASUSTeK Computer", true, 3),
        
        // Belkin default PINs
        WpsPin("00000000", "Belkin default", "Belkin International", true, 1),
        WpsPin("12345670", "Belkin common", "Belkin International", true, 2),
        WpsPin("belkin54", "Belkin text PIN", "Belkin International", true, 3),
        
        // Buffalo default PINs
        WpsPin("12345670", "Buffalo default", "Buffalo Inc.", true, 1),
        WpsPin("00000000", "Buffalo variant", "Buffalo Inc.", true, 2),
        WpsPin("password", "Buffalo text PIN", "Buffalo Inc.", true, 3),
        
        // ZyXEL default PINs
        WpsPin("12345670", "ZyXEL default", "ZyXEL Communications", true, 1),
        WpsPin("1234567890", "ZyXEL extended", "ZyXEL Communications", true, 2),
        WpsPin("00000000", "ZyXEL variant", "ZyXEL Communications", true, 3),
        
        // Tenda default PINs
        WpsPin("12345670", "Tenda default", "Shenzhen Tenda Technology", true, 1),
        WpsPin("00000000", "Tenda variant", "Shenzhen Tenda Technology", true, 2),
        WpsPin("admin123", "Tenda admin", "Shenzhen Tenda Technology", true, 3)
    )
    
    // Offline vulnerable manufacturer OUIs (no internet required)
    fun getVulnerableManufacturerOuis(): Set<String> = setOf(
        // Known vulnerable TP-Link OUIs
        "14:CC:20", "18:D6:C7", "1C:61:B4", "20:F4:78", "24:A4:3C",
        "28:6C:07", "2C:30:33", "30:B5:C2", "34:08:04", "38:2C:4A",
        
        // Known vulnerable D-Link OUIs
        "00:05:5D", "00:0D:88", "00:11:95", "00:13:46", "00:15:E9",
        "14:D6:4D", "1C:7E:E5", "20:CF:30", "28:10:7B", "2C:AB:A4",
        
        // Known vulnerable Netgear OUIs
        "00:09:5B", "00:0F:B5", "00:14:6C", "00:18:4D", "00:1B:2F",
        "20:4E:7F", "28:C6:8E", "30:46:9A", "40:0D:10", "44:94:FC",
        
        // Known vulnerable Belkin OUIs
        "00:11:50", "00:17:3F", "00:1C:DF", "00:22:75", "94:44:52",
        
        // Known vulnerable Buffalo OUIs
        "00:07:40", "00:16:01", "00:19:DB", "00:24:A5", "10:6F:3F",
        
        // Known vulnerable ZyXEL OUIs  
        "00:02:CF", "00:A0:C5", "28:28:5D", "40:4A:03", "B4:EE:B4"
    )
    
    // Offline security recommendations (no internet required)
    fun getSecurityRecommendations(network: WifiNetwork): List<String> {
        val recommendations = mutableListOf<String>()
        
        if (network.isWpsEnabled) {
            recommendations.add("🔒 Disable WPS on your router - it's a major security vulnerability")
            recommendations.add("🔑 Use WPA3 or WPA2 with a strong password instead")
        }
        
        when (network.securityType) {
            SecurityType.OPEN -> {
                recommendations.add("⚠️ This network is completely open - anyone can connect")
                recommendations.add("🛡️ Enable WPA3 or WPA2 security immediately")
            }
            SecurityType.WEP -> {
                recommendations.add("🚨 WEP encryption is extremely vulnerable and easily cracked")
                recommendations.add("🔄 Upgrade to WPA3 or WPA2 immediately")
            }
            SecurityType.WPA -> {
                recommendations.add("⚠️ WPA is outdated and has known vulnerabilities")
                recommendations.add("🔄 Upgrade to WPA3 or WPA2")
            }
            SecurityType.WPA2 -> {
                recommendations.add("✅ WPA2 is reasonably secure")
                recommendations.add("🔄 Consider upgrading to WPA3 if available")
            }
            SecurityType.WPA3 -> {
                recommendations.add("✅ WPA3 is the most secure option available")
            }
            else -> {
                recommendations.add("❓ Unknown security type - verify your router settings")
            }
        }
        
        recommendations.add("🔄 Update your router firmware regularly")
        recommendations.add("🔑 Use a strong, unique password (12+ characters)")
        recommendations.add("📱 Change default admin credentials")
        recommendations.add("🌐 Disable remote management if not needed")
        
        return recommendations
    }
    
    // Offline CVE database for router vulnerabilities (no internet required)
    fun getKnownVulnerabilities(manufacturerOui: String): List<String> {
        val manufacturer = getManufacturerOuis()[manufacturerOui] ?: return emptyList()
        
        return when {
            manufacturer.contains("TP-Link") -> listOf(
                "CVE-2020-35576: Authentication bypass vulnerability",
                "CVE-2021-4045: Command injection vulnerability", 
                "CVE-2022-30075: Remote code execution",
                "Multiple WPS PIN brute force vulnerabilities"
            )
            manufacturer.contains("D-Link") -> listOf(
                "CVE-2019-17621: Authentication bypass",
                "CVE-2020-25078: Command injection",
                "CVE-2021-45382: Remote code execution",
                "Known WPS implementation flaws"
            )
            manufacturer.contains("Netgear") -> listOf(
                "CVE-2020-27861: Authentication bypass",
                "CVE-2021-34991: Remote code execution",
                "CVE-2022-27644: Command injection",
                "WPS Pixie Dust vulnerability"
            )
            manufacturer.contains("Linksys") -> listOf(
                "CVE-2020-35713: Authentication bypass",
                "CVE-2021-46395: Command injection",
                "Default WPS PIN vulnerabilities"
            )
            else -> emptyList()
        }
    }
}