package com.wifiwpstester.noroot.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wifiwpstester.noroot.data.model.*
import com.wifiwpstester.noroot.data.repository.OfflineDataRepository
import com.wifiwpstester.noroot.data.service.WifiScannerService
import com.wifiwpstester.noroot.data.service.WpsTestingService
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class MainViewModel @Inject constructor(
    private val wifiScannerService: WifiScannerService,
    private val wpsTestingService: WpsTestingService,
    private val offlineDataRepository: OfflineDataRepository
) : ViewModel() {
    
    // WiFi Scanner State
    val scanResults = wifiScannerService.scanResults.asStateFlow()
    val isScanning = wifiScannerService.isScanning.asStateFlow()
    val scanError = wifiScannerService.scanError.asStateFlow()
    
    // WPS Testing State
    val testProgress = wpsTestingService.testProgress.asStateFlow()
    val testResult = wpsTestingService.testResult.asStateFlow()
    
    // Database State
    private val _allNetworks = MutableStateFlow<List<WifiNetwork>>(emptyList())
    val allNetworks = _allNetworks.asStateFlow()
    
    private val _wpsEnabledNetworks = MutableStateFlow<List<WifiNetwork>>(emptyList())
    val wpsEnabledNetworks = _wpsEnabledNetworks.asStateFlow()
    
    private val _allTestResults = MutableStateFlow<List<WpsTestResult>>(emptyList())
    val allTestResults = _allTestResults.asStateFlow()
    
    private val _selectedNetwork = MutableStateFlow<WifiNetwork?>(null)
    val selectedNetwork = _selectedNetwork.asStateFlow()
    
    // UI State
    private val _currentTab = MutableStateFlow(0)
    val currentTab = _currentTab.asStateFlow()
    
    private val _isDarkMode = MutableStateFlow(false)
    val isDarkMode = _isDarkMode.asStateFlow()
    
    // Statistics
    private val _statistics = MutableStateFlow<TestStatistics?>(null)
    val statistics = _statistics.asStateFlow()
    
    init {
        // Observe database changes
        viewModelScope.launch {
            offlineDataRepository.getAllNetworks().collect { networks ->
                _allNetworks.value = networks
            }
        }
        
        viewModelScope.launch {
            offlineDataRepository.getWpsEnabledNetworks().collect { networks ->
                _wpsEnabledNetworks.value = networks
            }
        }
        
        viewModelScope.launch {
            offlineDataRepository.getAllTestResults().collect { results ->
                _allTestResults.value = results
                updateStatistics(results)
            }
        }
    }
    
    // WiFi Scanner Functions
    fun startWifiScan() {
        wifiScannerService.startScan()
    }
    
    fun clearScanError() {
        wifiScannerService.clearError()
    }
    
    // WPS Testing Functions
    fun startWpsTest(
        network: WifiNetwork,
        testType: TestType,
        customPins: List<String> = emptyList(),
        delayBetweenAttempts: Long = 1000L
    ) {
        wpsTestingService.startWpsTest(network, testType, customPins, delayBetweenAttempts)
    }
    
    fun cancelWpsTest() {
        wpsTestingService.cancelTest()
    }
    
    fun clearTestResults() {
        wpsTestingService.clearResults()
    }
    
    // Network Selection
    fun selectNetwork(network: WifiNetwork?) {
        _selectedNetwork.value = network
    }
    
    // Tab Navigation
    fun setCurrentTab(tab: Int) {
        _currentTab.value = tab
    }
    
    // Theme Management
    fun toggleDarkMode() {
        _isDarkMode.value = !_isDarkMode.value
    }
    
    fun setDarkMode(isDark: Boolean) {
        _isDarkMode.value = isDark
    }
    
    // Security Analysis Functions
    fun getSecurityRecommendations(network: WifiNetwork): List<String> {
        return offlineDataRepository.getSecurityRecommendations(network)
    }
    
    fun getKnownVulnerabilities(network: WifiNetwork): List<String> {
        return network.manufacturerOui?.let { oui ->
            offlineDataRepository.getKnownVulnerabilities(oui)
        } ?: emptyList()
    }
    
    fun getManufacturerName(network: WifiNetwork): String? {
        return network.manufacturerOui?.let { oui ->
            offlineDataRepository.getManufacturerOuis()[oui]
        }
    }
    
    fun getDefaultPinsForNetwork(network: WifiNetwork): List<WpsPin> {
        val allPins = offlineDataRepository.getDefaultWpsPins()
        val manufacturerName = getManufacturerName(network)
        
        return if (manufacturerName != null) {
            allPins.filter { it.manufacturer == manufacturerName }
        } else {
            allPins.filter { it.manufacturer == null }
        }.sortedBy { it.priority }
    }
    
    fun getRiskLevel(network: WifiNetwork): RiskLevel {
        return when {
            !network.isWpsEnabled -> RiskLevel.LOW
            network.securityType == SecurityType.OPEN -> RiskLevel.CRITICAL
            network.securityType == SecurityType.WEP -> RiskLevel.CRITICAL
            network.securityType == SecurityType.WPA -> RiskLevel.HIGH
            network.manufacturerOui?.let { 
                offlineDataRepository.getVulnerableManufacturerOuis().contains(it) 
            } == true -> RiskLevel.HIGH
            network.isWpsEnabled -> RiskLevel.MEDIUM
            else -> RiskLevel.LOW
        }
    }
    
    // Search and Filter Functions
    fun searchNetworks(query: String): Flow<List<WifiNetwork>> {
        return if (query.isBlank()) {
            _allNetworks
        } else {
            _allNetworks.map { networks ->
                networks.filter { network ->
                    network.ssid.contains(query, ignoreCase = true) ||
                    network.bssid.contains(query, ignoreCase = true) ||
                    getManufacturerName(network)?.contains(query, ignoreCase = true) == true
                }
            }
        }
    }
    
    fun filterNetworksByRisk(riskLevel: RiskLevel): Flow<List<WifiNetwork>> {
        return _allNetworks.map { networks ->
            networks.filter { getRiskLevel(it) == riskLevel }
        }
    }
    
    fun filterNetworksBySecurityType(securityType: SecurityType): Flow<List<WifiNetwork>> {
        return _allNetworks.map { networks ->
            networks.filter { it.securityType == securityType }
        }
    }
    
    // Test History Functions
    fun getTestResultsForNetwork(network: WifiNetwork): Flow<List<WpsTestResult>> {
        return offlineDataRepository.getTestResultsForNetwork(network.bssid)
    }
    
    fun searchTestResults(query: String): Flow<List<WpsTestResult>> {
        return if (query.isBlank()) {
            _allTestResults
        } else {
            _allTestResults.map { results ->
                results.filter { result ->
                    result.networkSsid.contains(query, ignoreCase = true) ||
                    result.networkBssid.contains(query, ignoreCase = true) ||
                    result.notes.contains(query, ignoreCase = true)
                }
            }
        }
    }
    
    // Statistics Functions
    private fun updateStatistics(results: List<WpsTestResult>) {
        if (results.isEmpty()) {
            _statistics.value = null
            return
        }
        
        val totalTests = results.size
        val successfulTests = results.count { it.result == TestResult.SUCCESS }
        val failedTests = results.count { it.result == TestResult.FAILED }
        val averageDuration = results.map { it.duration }.average().toLong()
        
        val manufacturerSuccessRate = results
            .groupBy { getManufacturerFromBssid(it.networkBssid) }
            .mapValues { (_, tests) ->
                tests.count { it.result == TestResult.SUCCESS }.toFloat() / tests.size
            }
        val mostVulnerableManufacturer = manufacturerSuccessRate.maxByOrNull { it.value }?.key
        
        val riskDistribution = results
            .groupBy { it.riskLevel }
            .mapValues { it.value.size }
        
        _statistics.value = TestStatistics(
            totalTests = totalTests,
            successfulTests = successfulTests,
            failedTests = failedTests,
            averageDuration = averageDuration,
            mostVulnerableManufacturer = mostVulnerableManufacturer,
            riskDistribution = riskDistribution
        )
    }
    
    private fun getManufacturerFromBssid(bssid: String): String? {
        val oui = try {
            val macParts = bssid.split(":")
            if (macParts.size >= 3) {
                "${macParts[0]}:${macParts[1]}:${macParts[2]}".uppercase()
            } else null
        } catch (e: Exception) {
            null
        }
        
        return oui?.let { offlineDataRepository.getManufacturerOuis()[it] }
    }
    
    // Export Functions
    suspend fun exportTestResults(format: ExportFormat): String {
        // This would implement export functionality
        // For now, return a placeholder
        return when (format) {
            ExportFormat.JSON -> exportAsJson()
            ExportFormat.CSV -> exportAsCsv()
            ExportFormat.PDF -> exportAsPdf()
        }
    }
    
    private suspend fun exportAsJson(): String {
        // Implementation for JSON export
        return "exported_results.json"
    }
    
    private suspend fun exportAsCsv(): String {
        // Implementation for CSV export
        return "exported_results.csv"
    }
    
    private suspend fun exportAsPdf(): String {
        // Implementation for PDF export
        return "exported_results.pdf"
    }
    
    enum class ExportFormat {
        JSON, CSV, PDF
    }
}