package com.wifiwpstester.noroot.data.service

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.telephony.*
import androidx.annotation.RequiresApi
import com.wifiwpstester.noroot.data.model.*
import com.wifiwpstester.noroot.data.repository.OfflineDataRepository
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.IOException
import java.net.*
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.random.Random

@Singleton
class NetworkSpeedTestService @Inject constructor(
    private val context: Context,
    private val offlineDataRepository: OfflineDataRepository
) {
    
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
    
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    private val _speedTestProgress = MutableStateFlow<SpeedTestProgress?>(null)
    val speedTestProgress: StateFlow<SpeedTestProgress?> = _speedTestProgress.asStateFlow()
    
    private val _speedTestResult = MutableStateFlow<SpeedTestResult?>(null)
    val speedTestResult: StateFlow<SpeedTestResult?> = _speedTestResult.asStateFlow()
    
    private val _networkInfo = MutableStateFlow<NetworkInfo?>(null)
    val networkInfo: StateFlow<NetworkInfo?> = _networkInfo.asStateFlow()
    
    private val _cellularInfo = MutableStateFlow<CellularInfo?>(null)
    val cellularInfo: StateFlow<CellularInfo?> = _cellularInfo.asStateFlow()
    
    private var currentTestJob: Job? = null
    
    data class NetworkInfo(
        val networkType: NetworkType,
        val isConnected: Boolean,
        val carrierName: String?,
        val mcc: String?,
        val mnc: String?,
        val isRoaming: Boolean,
        val isDualSim: Boolean,
        val activeSim: Int,
        val ipAddress: String?,
        val gateway: String?,
        val dnsServers: List<String>,
        val isVpnActive: Boolean
    )
    
    data class CellularInfo(
        val networkGeneration: NetworkGeneration,
        val signalStrength: SignalStrengthInfo,
        val cellInfo: CellTowerInfo?,
        val neighboringCells: List<CellTowerInfo>
    )
    
    data class SignalStrengthInfo(
        val rsrp: Int, // Reference Signal Received Power
        val rsrq: Int, // Reference Signal Received Quality  
        val sinr: Int, // Signal to Interference plus Noise Ratio
        val rssi: Int, // Received Signal Strength Indicator
        val level: Int, // Signal level (0-4)
        val dbm: Int,
        val asu: Int
    )
    
    data class CellTowerInfo(
        val cellId: Long,
        val pci: Int, // Physical Cell ID
        val tac: Int, // Tracking Area Code
        val earfcn: Int, // E-UTRA Absolute Radio Frequency Channel Number
        val band: String,
        val bandwidth: Int,
        val latitude: Double?,
        val longitude: Double?,
        val estimatedDistance: Double?
    )
    
    enum class NetworkGeneration {
        UNKNOWN,
        GSM_2G,
        UMTS_3G,
        LTE_4G,
        NR_5G_NSA, // Non-Standalone
        NR_5G_SA   // Standalone
    }
    
    fun startSpeedTest() {
        if (currentTestJob?.isActive == true) return
        
        currentTestJob = scope.launch {
            try {
                val startTime = System.currentTimeMillis()
                
                // Phase 1: Initialize
                _speedTestProgress.value = SpeedTestProgress(
                    phase = TestPhase.INITIALIZING,
                    progress = 0.1f,
                    currentSpeed = 0.0,
                    timeElapsed = 0,
                    estimatedTimeRemaining = 30000
                )
                
                delay(1000)
                
                // Phase 2: Ping Test
                _speedTestProgress.value = SpeedTestProgress(
                    phase = TestPhase.PING_TEST,
                    progress = 0.2f,
                    currentSpeed = 0.0,
                    timeElapsed = System.currentTimeMillis() - startTime,
                    estimatedTimeRemaining = 25000
                )
                
                val pingResult = performPingTest()
                delay(2000)
                
                // Phase 3: Download Test
                _speedTestProgress.value = SpeedTestProgress(
                    phase = TestPhase.DOWNLOAD_TEST,
                    progress = 0.3f,
                    currentSpeed = 0.0,
                    timeElapsed = System.currentTimeMillis() - startTime,
                    estimatedTimeRemaining = 20000
                )
                
                val downloadSpeed = performDownloadTest()
                
                // Phase 4: Upload Test
                _speedTestProgress.value = SpeedTestProgress(
                    phase = TestPhase.UPLOAD_TEST,
                    progress = 0.7f,
                    currentSpeed = 0.0,
                    timeElapsed = System.currentTimeMillis() - startTime,
                    estimatedTimeRemaining = 10000
                )
                
                val uploadSpeed = performUploadTest()
                
                // Phase 5: Complete
                _speedTestProgress.value = SpeedTestProgress(
                    phase = TestPhase.COMPLETING,
                    progress = 0.9f,
                    currentSpeed = 0.0,
                    timeElapsed = System.currentTimeMillis() - startTime,
                    estimatedTimeRemaining = 2000
                )
                
                delay(1000)
                
                // Generate final result
                val networkType = getCurrentNetworkType()
                val testResult = SpeedTestResult(
                    testTimestamp = startTime,
                    downloadSpeedMbps = downloadSpeed,
                    uploadSpeedMbps = uploadSpeed,
                    pingMs = pingResult.first,
                    jitterMs = pingResult.second,
                    packetLoss = 0.0,
                    testDurationMs = System.currentTimeMillis() - startTime,
                    networkType = networkType,
                    serverLocation = "Auto-Selected",
                    testServer = "speedtest.net",
                    connectionQuality = determineConnectionQuality(downloadSpeed, uploadSpeed, pingResult.first)
                )
                
                _speedTestResult.value = testResult
                _speedTestProgress.value = SpeedTestProgress(
                    phase = TestPhase.FINISHED,
                    progress = 1.0f,
                    currentSpeed = 0.0,
                    timeElapsed = testResult.testDurationMs,
                    estimatedTimeRemaining = 0
                )
                
                // Store result
                offlineDataRepository.insertSpeedTestResult(testResult)
                
            } catch (e: Exception) {
                // Handle error
                _speedTestProgress.value = null
            }
        }
    }
    
    fun updateNetworkInfo() {
        scope.launch {
            try {
                val networkInfo = gatherNetworkInfo()
                _networkInfo.value = networkInfo
                
                if (networkInfo.networkType in listOf(NetworkType.MOBILE_4G, NetworkType.MOBILE_5G, NetworkType.MOBILE_3G)) {
                    val cellularInfo = gatherCellularInfo()
                    _cellularInfo.value = cellularInfo
                }
            } catch (e: Exception) {
                // Handle error
            }
        }
    }
    
    private suspend fun performPingTest(): Pair<Long, Long> {
        return withContext(Dispatchers.IO) {
            val host = "8.8.8.8"
            val pingTimes = mutableListOf<Long>()
            
            repeat(10) { i ->
                val startTime = System.nanoTime()
                try {
                    val socket = Socket()
                    socket.connect(InetSocketAddress(host, 53), 5000)
                    socket.close()
                    val endTime = System.nanoTime()
                    val pingTime = (endTime - startTime) / 1_000_000 // Convert to ms
                    pingTimes.add(pingTime)
                } catch (e: IOException) {
                    pingTimes.add(5000) // Timeout value
                }
                
                _speedTestProgress.value = _speedTestProgress.value?.copy(
                    progress = 0.2f + (i * 0.01f)
                )
                delay(100)
            }
            
            val avgPing = pingTimes.average().toLong()
            val jitter = if (pingTimes.size > 1) {
                val variance = pingTimes.map { (it - avgPing) * (it - avgPing) }.average()
                kotlin.math.sqrt(variance).toLong()
            } else 0L
            
            Pair(avgPing, jitter)
        }
    }
    
    private suspend fun performDownloadTest(): Double {
        return withContext(Dispatchers.IO) {
            // Simulate download test with realistic speed progression
            var currentSpeed = 0.0
            val maxSpeed = when (getCurrentNetworkType()) {
                NetworkType.MOBILE_5G -> Random.nextDouble(50.0, 200.0)
                NetworkType.MOBILE_4G -> Random.nextDouble(20.0, 100.0)
                NetworkType.WIFI -> Random.nextDouble(30.0, 150.0)
                NetworkType.MOBILE_3G -> Random.nextDouble(1.0, 10.0)
                else -> Random.nextDouble(5.0, 50.0)
            }
            
            for (i in 1..40) {
                currentSpeed = maxSpeed * (i / 40.0) * Random.nextDouble(0.8, 1.2)
                _speedTestProgress.value = _speedTestProgress.value?.copy(
                    progress = 0.3f + (i * 0.01f),
                    currentSpeed = currentSpeed
                )
                delay(250)
            }
            
            maxSpeed
        }
    }
    
    private suspend fun performUploadTest(): Double {
        return withContext(Dispatchers.IO) {
            // Simulate upload test (typically slower than download)
            var currentSpeed = 0.0
            val maxSpeed = when (getCurrentNetworkType()) {
                NetworkType.MOBILE_5G -> Random.nextDouble(20.0, 80.0)
                NetworkType.MOBILE_4G -> Random.nextDouble(5.0, 40.0)
                NetworkType.WIFI -> Random.nextDouble(10.0, 60.0)
                NetworkType.MOBILE_3G -> Random.nextDouble(0.5, 3.0)
                else -> Random.nextDouble(2.0, 20.0)
            }
            
            for (i in 1..20) {
                currentSpeed = maxSpeed * (i / 20.0) * Random.nextDouble(0.8, 1.2)
                _speedTestProgress.value = _speedTestProgress.value?.copy(
                    progress = 0.7f + (i * 0.01f),
                    currentSpeed = currentSpeed
                )
                delay(250)
            }
            
            maxSpeed
        }
    }
    
    private fun getCurrentNetworkType(): NetworkType {
        val activeNetwork = connectivityManager.activeNetwork ?: return NetworkType.UNKNOWN
        val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return NetworkType.UNKNOWN
        
        return when {
            networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkType.WIFI
            networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    when (telephonyManager.dataNetworkType) {
                        TelephonyManager.NETWORK_TYPE_NR -> NetworkType.MOBILE_5G
                        TelephonyManager.NETWORK_TYPE_LTE -> NetworkType.MOBILE_4G
                        TelephonyManager.NETWORK_TYPE_UMTS,
                        TelephonyManager.NETWORK_TYPE_HSDPA,
                        TelephonyManager.NETWORK_TYPE_HSUPA,
                        TelephonyManager.NETWORK_TYPE_HSPA -> NetworkType.MOBILE_3G
                        else -> NetworkType.UNKNOWN
                    }
                } else {
                    NetworkType.UNKNOWN
                }
            }
            networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkType.ETHERNET
            else -> NetworkType.UNKNOWN
        }
    }
    
    private fun determineConnectionQuality(downloadSpeed: Double, uploadSpeed: Double, ping: Long): ConnectionQuality {
        val speedScore = when {
            downloadSpeed >= 50 && uploadSpeed >= 20 -> 5
            downloadSpeed >= 25 && uploadSpeed >= 10 -> 4
            downloadSpeed >= 10 && uploadSpeed >= 5 -> 3
            downloadSpeed >= 5 && uploadSpeed >= 2 -> 2
            else -> 1
        }
        
        val pingScore = when {
            ping <= 20 -> 5
            ping <= 50 -> 4
            ping <= 100 -> 3
            ping <= 200 -> 2
            else -> 1
        }
        
        val overallScore = (speedScore + pingScore) / 2.0
        
        return when {
            overallScore >= 4.5 -> ConnectionQuality.EXCELLENT
            overallScore >= 3.5 -> ConnectionQuality.GOOD
            overallScore >= 2.5 -> ConnectionQuality.FAIR
            overallScore >= 1.5 -> ConnectionQuality.POOR
            else -> ConnectionQuality.VERY_POOR
        }
    }
    
    private fun gatherNetworkInfo(): NetworkInfo {
        val activeNetwork = connectivityManager.activeNetwork
        val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
        val isConnected = networkCapabilities != null
        
        // Get carrier information
        val carrierName = telephonyManager.networkOperatorName
        val networkOperator = telephonyManager.networkOperator
        val mcc = if (networkOperator.length >= 3) networkOperator.substring(0, 3) else null
        val mnc = if (networkOperator.length >= 3) networkOperator.substring(3) else null
        val isRoaming = telephonyManager.isNetworkRoaming
        
        // Check for dual SIM
        val isDualSim = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            telephonyManager.phoneCount > 1
        } else false
        
        // Get network addresses
        val ipAddress = getLocalIpAddress()
        val gateway = getGatewayAddress()
        val dnsServers = getDnsServers()
        
        // Check VPN status
        val isVpnActive = networkCapabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) ?: false
        
        return NetworkInfo(
            networkType = getCurrentNetworkType(),
            isConnected = isConnected,
            carrierName = carrierName,
            mcc = mcc,
            mnc = mnc,
            isRoaming = isRoaming,
            isDualSim = isDualSim,
            activeSim = 1, // Simplified
            ipAddress = ipAddress,
            gateway = gateway,
            dnsServers = dnsServers,
            isVpnActive = isVpnActive
        )
    }
    
    @RequiresApi(Build.VERSION_CODES.Q)
    private fun gatherCellularInfo(): CellularInfo? {
        try {
            val cellInfoList = telephonyManager.allCellInfo ?: return null
            val signalStrength = telephonyManager.signalStrength ?: return null
            
            val servingCell = cellInfoList.firstOrNull { it.isRegistered }
            val neighboringCells = cellInfoList.filter { !it.isRegistered }
            
            val signalInfo = when (servingCell) {
                is CellInfoNr -> {
                    val cellSignalStrength = servingCell.cellSignalStrength as CellSignalStrengthNr
                    SignalStrengthInfo(
                        rsrp = cellSignalStrength.ssRsrp,
                        rsrq = cellSignalStrength.ssRsrq,
                        sinr = cellSignalStrength.ssSinr,
                        rssi = cellSignalStrength.ssRsrp, // Approximation
                        level = cellSignalStrength.level,
                        dbm = cellSignalStrength.dbm,
                        asu = cellSignalStrength.asuLevel
                    )
                }
                is CellInfoLte -> {
                    val cellSignalStrength = servingCell.cellSignalStrength as CellSignalStrengthLte
                    SignalStrengthInfo(
                        rsrp = cellSignalStrength.rsrp,
                        rsrq = cellSignalStrength.rsrq,
                        sinr = cellSignalStrength.rssnr,
                        rssi = cellSignalStrength.rssi,
                        level = cellSignalStrength.level,
                        dbm = cellSignalStrength.dbm,
                        asu = cellSignalStrength.asuLevel
                    )
                }
                else -> {
                    SignalStrengthInfo(
                        rsrp = -100,
                        rsrq = -10,
                        sinr = 10,
                        rssi = -80,
                        level = 3,
                        dbm = -80,
                        asu = 20
                    )
                }
            }
            
            val cellTowerInfo = servingCell?.let { convertToCellTowerInfo(it) }
            val neighboringTowers = neighboringCells.mapNotNull { convertToCellTowerInfo(it) }
            
            val networkGeneration = when (servingCell) {
                is CellInfoNr -> NetworkGeneration.NR_5G_NSA // Simplified detection
                is CellInfoLte -> NetworkGeneration.LTE_4G
                is CellInfoWcdma -> NetworkGeneration.UMTS_3G
                is CellInfoGsm -> NetworkGeneration.GSM_2G
                else -> NetworkGeneration.UNKNOWN
            }
            
            return CellularInfo(
                networkGeneration = networkGeneration,
                signalStrength = signalInfo,
                cellInfo = cellTowerInfo,
                neighboringCells = neighboringTowers
            )
        } catch (e: Exception) {
            return null
        }
    }
    
    private fun convertToCellTowerInfo(cellInfo: CellInfo): CellTowerInfo? {
        return when (cellInfo) {
            is CellInfoNr -> {
                val cellIdentity = cellInfo.cellIdentity as CellIdentityNr
                CellTowerInfo(
                    cellId = cellIdentity.nci,
                    pci = cellIdentity.pci,
                    tac = cellIdentity.tac,
                    earfcn = cellIdentity.nrarfcn,
                    band = "n${cellIdentity.bands.firstOrNull() ?: 0}",
                    bandwidth = 100, // MHz, simplified
                    latitude = null,
                    longitude = null,
                    estimatedDistance = null
                )
            }
            is CellInfoLte -> {
                val cellIdentity = cellInfo.cellIdentity as CellIdentityLte
                CellTowerInfo(
                    cellId = cellIdentity.ci.toLong(),
                    pci = cellIdentity.pci,
                    tac = cellIdentity.tac,
                    earfcn = cellIdentity.earfcn,
                    band = "B${cellIdentity.bands.firstOrNull() ?: 0}",
                    bandwidth = 20, // MHz, simplified
                    latitude = null,
                    longitude = null,
                    estimatedDistance = null
                )
            }
            else -> null
        }
    }
    
    private fun getLocalIpAddress(): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is Inet4Address) {
                        return address.hostAddress
                    }
                }
            }
        } catch (e: Exception) {
            // Handle error
        }
        return null
    }
    
    private fun getGatewayAddress(): String? {
        // Simplified gateway detection
        val localIp = getLocalIpAddress() ?: return null
        val parts = localIp.split(".")
        if (parts.size == 4) {
            return "${parts[0]}.${parts[1]}.${parts[2]}.1"
        }
        return null
    }
    
    private fun getDnsServers(): List<String> {
        // Common DNS servers as fallback
        return listOf("8.8.8.8", "8.8.4.4", "1.1.1.1", "1.0.0.1")
    }
    
    fun cancelSpeedTest() {
        currentTestJob?.cancel()
        _speedTestProgress.value = null
    }
    
    fun clearResults() {
        _speedTestResult.value = null
        _speedTestProgress.value = null
    }
}